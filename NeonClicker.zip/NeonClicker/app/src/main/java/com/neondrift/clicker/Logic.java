package com.neondrift.clicker;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Логика кликера без Android: сравнение цветов, состояние триггеров, очередь кликов, планирование жестов. */
final class Logic {
    private Logic() {}

    // ================================================================== цвета

    /** Разница двух цветов: наибольшая разница по каналам R, G, B (0–255). */
    static int diff(int a, int b) {
        int dr = Math.abs(((a >> 16) & 255) - ((b >> 16) & 255));
        int dg = Math.abs(((a >> 8) & 255) - ((b >> 8) & 255));
        int db = Math.abs((a & 255) - (b & 255));
        return Math.max(dr, Math.max(dg, db));
    }

    /** Допуск в процентах → допустимая разница каналов. */
    static int limit(int tolerancePct) {
        return Math.round(Math.max(0, Math.min(100, tolerancePct)) * 2.55f);
    }

    static boolean near(int a, int b, int tolerancePct) {
        return diff(a, b) <= limit(tolerancePct);
    }

    /** Сколько точек совпало со своими образцами (с учётом «≠»). */
    static int matchCount(Model.Trigger t, int[] colors) {
        int lim = limit(t.tolerance), n = 0;
        for (int i = 0; i < t.watches.size() && i < colors.length; i++) {
            Model.Watch w = t.watches.get(i);
            boolean ok = diff(colors[i], w.color) <= lim;
            if (ok != w.invert) n++;
        }
        return n;
    }

    /** Самая большая группа точек одного цвета: сколько точек близки к какой-нибудь одной. */
    static int sameCount(int[] colors, int n, int tolerancePct) {
        int lim = limit(tolerancePct), best = 0;
        for (int i = 0; i < n; i++) {
            int c = 0;
            for (int j = 0; j < n; j++) if (diff(colors[i], colors[j]) <= lim) c++;
            best = Math.max(best, c);
        }
        return best;
    }

    /** Выполнено ли условие триггера для текущих цветов в его точках. */
    static boolean condition(Model.Trigger t, int[] colors) {
        int n = Math.min(t.watches.size(), colors.length);
        if (n == 0) return false;
        int need = t.needed();
        if (t.mode == Model.SAME) {
            if (n < 2) return false;
            return sameCount(colors, n, t.tolerance) >= Math.max(2, need);
        }
        return matchCount(t, colors) >= need;
    }

    /** Подпись для режима: «совпали 2 из 3». */
    static String progress(Model.Trigger t, int[] colors) {
        int n = Math.min(t.watches.size(), colors.length);
        int have = t.mode == Model.SAME ? sameCount(colors, n, t.tolerance) : matchCount(t, colors);
        int need = t.mode == Model.SAME ? Math.max(2, t.needed()) : t.needed();
        return have + " из " + need;
    }

    // ================================================================== состояние триггера

    /**
     * Когда нажимать: условие должно продержаться holdMs; «один раз» — один клик на каждое появление условия;
     * «пока держится» — повтор с интервалом cooldownMs. Между срабатываниями не меньше cooldownMs.
     */
    static final class TriggerState {
        long since = -1, lastFire = Long.MIN_VALUE / 2;
        boolean firedThisTime;
        int fires;

        boolean update(Model.Trigger t, boolean cond, long now) {
            if (!cond) {
                since = -1;
                firedThisTime = false;
                return false;
            }
            if (since < 0) since = now;
            if (now - since < t.holdMs) return false;
            if (t.fire == Model.ONCE && firedThisTime) return false;
            if (now - lastFire < t.cooldownMs) return false;
            lastFire = now;
            firedThisTime = true;
            fires++;
            return true;
        }

        void reset() {
            since = -1;
            lastFire = Long.MIN_VALUE / 2;
            firedThisTime = false;
        }
    }

    // ================================================================== клики по кругу

    static final class Sequencer {
        final List<Model.Target> targets;
        final int cycles;
        int index, rep, cycle;
        long clicks;

        Sequencer(List<Model.Target> targets, int cycles) {
            this.targets = targets;
            this.cycles = cycles;
        }

        boolean finished() {
            return targets.isEmpty() || (cycles > 0 && cycle >= cycles);
        }

        /** Следующая точка или null, если круги закончились. */
        Model.Target next() {
            if (finished()) return null;
            if (index >= targets.size()) index = 0;
            Model.Target t = targets.get(index);
            rep++;
            if (rep >= Math.max(1, t.repeat)) {
                rep = 0;
                index++;
                if (index >= targets.size()) {
                    index = 0;
                    cycle++;
                }
            }
            clicks++;
            return t;
        }

        void reset() {
            index = rep = cycle = 0;
            clicks = 0;
        }
    }

    /** Пауза со случайной добавкой ±pct%. */
    static long jitter(long base, int pct, Random r) {
        if (pct <= 0 || base <= 0) return Math.max(0, base);
        long d = base * pct / 100;
        if (d <= 0) return base;
        return Math.max(0, base - d + (long) (r.nextDouble() * (2 * d + 1)));
    }

    // ================================================================== жесты

    /** Один «палец»: путь (одна точка — нажатие) с началом и длительностью. */
    static final class Stroke {
        final float[] xs, ys;
        final long start, duration;

        Stroke(float[] xs, float[] ys, long start, long duration) {
            this.xs = xs;
            this.ys = ys;
            this.start = start;
            this.duration = Math.max(1, duration);
        }

        long end() {
            return start + duration;
        }
    }

    static final long DOUBLE_GAP = 70;
    static final long MAX_GESTURE = 59_000;

    /** Жест для точки: набор «пальцев», которые отправляются системе одним вызовом. */
    static List<Stroke> plan(Model.Target t, Model.Scenario s, Random r, int screenW, int screenH) {
        ArrayList<Stroke> out = new ArrayList<>();
        float[] p = offset(t.x, t.y, s.jitterPx, r, screenW, screenH);
        long press = s.pressMs + (s.pressJitterMs > 0 ? (long) (r.nextDouble() * (s.pressJitterMs + 1)) : 0);
        switch (t.type) {
            case Model.DOUBLE:
                out.add(new Stroke(new float[]{p[0]}, new float[]{p[1]}, 0, press));
                out.add(new Stroke(new float[]{p[0]}, new float[]{p[1]}, press + DOUBLE_GAP, press));
                break;
            case Model.LONG:
                out.add(new Stroke(new float[]{p[0]}, new float[]{p[1]}, 0, Math.min(MAX_GESTURE, t.holdMs)));
                break;
            case Model.SWIPE: {
                float[] q = offset(t.x2, t.y2, s.jitterPx, r, screenW, screenH);
                out.add(new Stroke(new float[]{p[0], q[0]}, new float[]{p[1], q[1]}, 0, Math.min(MAX_GESTURE, t.holdMs)));
                break;
            }
            default:
                out.add(new Stroke(new float[]{p[0]}, new float[]{p[1]}, 0, press));
        }
        return out;
    }

    /** Несколько точек одновременно (мультитач): все «пальцы» в одном жесте. */
    static List<Stroke> together(List<Model.Target> ts, Model.Scenario s, Random r, int screenW, int screenH, int maxStrokes) {
        ArrayList<Stroke> out = new ArrayList<>();
        for (Model.Target t : ts) {
            for (Stroke st : plan(t, s, r, screenW, screenH)) {
                if (out.size() >= maxStrokes) return out;
                out.add(st);
            }
        }
        return out;
    }

    /** Случайный сдвиг внутри круга радиуса px, не выходя за экран. */
    static float[] offset(int x, int y, int px, Random r, int w, int h) {
        float fx = x, fy = y;
        if (px > 0) {
            double a = r.nextDouble() * Math.PI * 2, d = px * Math.sqrt(r.nextDouble());
            fx += (float) (Math.cos(a) * d);
            fy += (float) (Math.sin(a) * d);
        }
        if (w > 0) fx = Math.max(0, Math.min(w - 1, fx));
        else fx = Math.max(0, fx);
        if (h > 0) fy = Math.max(0, Math.min(h - 1, fy));
        else fy = Math.max(0, fy);
        return new float[]{fx, fy};
    }

    static long gestureLength(List<Stroke> g) {
        long end = 0;
        for (Stroke s : g) end = Math.max(end, s.end());
        return end;
    }

    // ================================================================== подписи

    /** «150 мс», «1,5 с», «2 мин». */
    static String ms(long v) {
        if (v < 1000) return v + " мс";
        if (v < 60_000) {
            double sec = v / 1000.0;
            String s = sec == Math.floor(sec) ? String.valueOf((long) sec) : String.format(java.util.Locale.ROOT, "%.1f", sec).replace('.', ',');
            return s + " с";
        }
        long m = v / 60_000, sec = (v % 60_000) / 1000;
        if (m < 60) return sec == 0 ? m + " мин" : m + " мин " + sec + " с";
        long h = m / 60;
        return h + " ч" + (m % 60 > 0 ? " " + (m % 60) + " мин" : "");
    }

    /** Шаги для кнопок «−/+» у пауз: мелкие для коротких, крупные для длинных. */
    static long stepUp(long v) {
        if (v < 10) return v + 1;
        if (v < 100) return v + 10;
        if (v < 1000) return v + 50;
        if (v < 10_000) return v + 500;
        if (v < 60_000) return v + 5000;
        return v + 60_000;
    }

    static long stepDown(long v) {
        if (v <= 10) return Math.max(0, v - 1);
        if (v <= 100) return v - 10;
        if (v <= 1000) return v - 50;
        if (v <= 10_000) return v - 500;
        if (v <= 60_000) return v - 5000;
        return v - 60_000;
    }

    /** «00:41», «1:02:03». */
    static String clock(long ms) {
        long s = Math.max(0, ms / 1000), h = s / 3600, m = (s % 3600) / 60, sec = s % 60;
        String mm = m < 10 ? "0" + m : String.valueOf(m), ss = sec < 10 ? "0" + sec : String.valueOf(sec);
        return h > 0 ? h + ":" + mm + ":" + ss : mm + ":" + ss;
    }

    static String plural(long n, String one, String few, String many) {
        long a = Math.abs(n) % 100, b = a % 10;
        String w = a > 10 && a < 20 ? many : b == 1 ? one : b >= 2 && b <= 4 ? few : many;
        return n + " " + w;
    }
}
