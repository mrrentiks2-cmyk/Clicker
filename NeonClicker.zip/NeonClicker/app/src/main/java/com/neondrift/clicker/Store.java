package com.neondrift.clicker;

import android.content.Context;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Сценарии лежат JSON-файлами во внутренней памяти приложения. */
final class Store {
    private Store() {}

    static File dir(Context c) {
        File d = new File(c.getFilesDir(), "scenarios");
        if (!d.isDirectory()) d.mkdirs();
        return d;
    }

    private static File file(Context c, String id) {
        return new File(dir(c), id.replaceAll("[^A-Za-z0-9-]", "") + ".json");
    }

    static synchronized List<Model.Scenario> all(Context c) {
        ArrayList<Model.Scenario> out = new ArrayList<>();
        File[] fs = dir(c).listFiles((d, n) -> n.endsWith(".json"));
        if (fs != null) {
            for (File f : fs) {
                try {
                    out.add(Model.fromJson(read(new FileInputStream(f))));
                } catch (Exception ignored) {
                    // повреждённый файл пропускаем
                }
            }
        }
        out.sort((a, b) -> Long.compare(Math.max(b.lastRun, b.edited), Math.max(a.lastRun, a.edited)));
        return out;
    }

    static synchronized Model.Scenario load(Context c, String id) {
        if (id == null) return null;
        File f = file(c, id);
        if (!f.isFile()) return null;
        try {
            return Model.fromJson(read(new FileInputStream(f)));
        } catch (Exception e) {
            return null;
        }
    }

    static synchronized void save(Context c, Model.Scenario s) {
        if (s.created == 0) s.created = System.currentTimeMillis();
        File f = file(c, s.id), tmp = new File(f.getPath() + ".tmp");
        try (OutputStream out = new FileOutputStream(tmp)) {
            out.write(Model.toJson(s).getBytes(StandardCharsets.UTF_8));
        } catch (IOException e) {
            tmp.delete();
            return;
        }
        tmp.renameTo(f);
    }

    static synchronized void delete(Context c, String id) {
        file(c, id).delete();
    }

    static String read(InputStream in) throws IOException {
        try (InputStream is = in) {
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[16 * 1024];
            int n;
            while ((n = is.read(buf)) > 0) {
                bos.write(buf, 0, n);
                if (bos.size() > 8 * 1024 * 1024) throw new IOException("слишком большой файл");
            }
            return bos.toString("UTF-8");
        }
    }

    /** Имя, которого ещё нет: «Сценарий 3». */
    static String freeName(Context c, String base) {
        List<Model.Scenario> all = all(c);
        for (int i = 1; ; i++) {
            String n = i == 1 ? base : base + " " + i;
            boolean used = false;
            for (Model.Scenario s : all) if (s.name.equalsIgnoreCase(n)) used = true;
            if (!used) return n;
        }
    }
}
