package com.neondrift.clicker;

import android.content.Context;
import android.content.SharedPreferences;

/** Настройки приложения. */
final class Prefs {
    private final SharedPreferences sp;

    Prefs(Context c) {
        sp = c.getSharedPreferences("settings", Context.MODE_PRIVATE);
    }

    int accent() { return sp.getInt("accent", 0); }
    /** Громкость вниз — аварийная остановка. */
    boolean volumeStop() { return sp.getBoolean("volumeStop", true); }
    boolean showStats() { return sp.getBoolean("showStats", true); }
    int markerSize() { return sp.getInt("markerSize", 100); }
    int panelX() { return sp.getInt("panelX", -1); }
    int panelY() { return sp.getInt("panelY", -1); }
    String lastScenario() { return sp.getString("lastScenario", null); }
    boolean seenGuide() { return sp.getBoolean("seenGuide", false); }

    void put(String k, boolean v) { sp.edit().putBoolean(k, v).apply(); }
    void put(String k, int v) { sp.edit().putInt(k, v).apply(); }
    void put(String k, String v) { sp.edit().putString(k, v).apply(); }
}
