package com.neondrift.clicker;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.WindowManager;

import java.nio.ByteBuffer;

/**
 * Запись экрана для триггеров по цвету. Кадры идут в ImageReader, последний кадр держим открытым
 * и читаем из него нужные пиксели прямо из буфера — это быстро, десятки проверок в секунду.
 */
public class CaptureService extends Service implements ColorSource {
    static volatile CaptureService instance;
    static final String CHANNEL = "capture";

    private MediaProjection projection;
    private VirtualDisplay display;
    private ImageReader reader;
    private HandlerThread thread;
    private Handler handler;
    private final Object lock = new Object();
    private Image current;
    private int width, height, dpi;
    private DisplayManager.DisplayListener displayListener;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "stop".equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        startForegroundNow();
        if (intent == null || projection != null) return START_NOT_STICKY;
        int code = intent.getIntExtra("code", 0);
        Intent data = intent.getParcelableExtra("data");
        MediaProjectionManager mpm = getSystemService(MediaProjectionManager.class);
        try {
            projection = mpm.getMediaProjection(code, data);
        } catch (Exception e) {
            projection = null;
        }
        if (projection == null) {
            ClickService.onCapture(false);
            stopSelf();
            return START_NOT_STICKY;
        }
        thread = new HandlerThread("neon-capture");
        thread.start();
        handler = new Handler(thread.getLooper());
        projection.registerCallback(new MediaProjection.Callback() {
            @Override
            public void onStop() {
                stopSelf();
            }
        }, handler);
        try {
            setup();
        } catch (Exception e) {
            ClickService.onCapture(false);
            stopSelf();
            return START_NOT_STICKY;
        }
        instance = this;
        ClickService.onCapture(true);
        return START_NOT_STICKY;
    }

    private void startForegroundNow() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm.getNotificationChannel(CHANNEL) == null) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Чтение цветов экрана", NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            nm.createNotificationChannel(ch);
        }
        Intent stop = new Intent(this, CaptureService.class).setAction("stop");
        Notification n = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat_click)
                .setContentTitle("Neon Clicker видит экран")
                .setContentText("Нужно для кликов по цвету. Нажмите «Выключить», когда закончите.")
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(null, "Выключить",
                        PendingIntent.getService(this, 1, stop, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT)).build())
                .build();
        if (Build.VERSION.SDK_INT >= 29) startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        else startForeground(2, n);
    }

    private void readSize() {
        DisplayMetrics dm = new DisplayMetrics();
        Display d = getSystemService(WindowManager.class).getDefaultDisplay();
        d.getRealMetrics(dm);
        width = dm.widthPixels;
        height = dm.heightPixels;
        dpi = dm.densityDpi;
    }

    private void setup() {
        readSize();
        reader = newReader();
        display = projection.createVirtualDisplay("neon-clicker", width, height, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, handler);
        DisplayManager dm = getSystemService(DisplayManager.class);
        displayListener = new DisplayManager.DisplayListener() {
            public void onDisplayAdded(int id) {}
            public void onDisplayRemoved(int id) {}
            public void onDisplayChanged(int id) {
                if (id == Display.DEFAULT_DISPLAY) handler.post(CaptureService.this::onRotate);
            }
        };
        dm.registerDisplayListener(displayListener, handler);
    }

    private ImageReader newReader() {
        ImageReader r = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 3);
        r.setOnImageAvailableListener(rd -> {
            Image img;
            try {
                img = rd.acquireLatestImage();
            } catch (Exception e) {
                return;
            }
            if (img == null) return;
            synchronized (lock) {
                if (current != null) current.close();
                current = img;
            }
        }, handler);
        return r;
    }

    /** Поворот экрана: пересоздаём приёмник под новый размер. */
    private void onRotate() {
        int ow = width, oh = height;
        readSize();
        if (ow == width && oh == height || display == null) return;
        ImageReader old = reader;
        synchronized (lock) {
            if (current != null) current.close();
            current = null;
        }
        reader = newReader();
        try {
            display.resize(width, height, dpi);
            display.setSurface(reader.getSurface());
        } catch (Exception ignored) {
        }
        old.close();
    }

    // ================================================================== ColorSource

    @Override
    public boolean ready() {
        synchronized (lock) {
            return current != null;
        }
    }

    @Override
    public int color(int x, int y) {
        synchronized (lock) {
            if (current == null) return 0;
            try {
                Image.Plane p = current.getPlanes()[0];
                ByteBuffer b = p.getBuffer();
                int ps = p.getPixelStride(), rs = p.getRowStride(), w = current.getWidth(), h = current.getHeight();
                int r = 0, g = 0, bl = 0, n = 0;
                for (int dy = -1; dy <= 1; dy++) {
                    int yy = y + dy;
                    if (yy < 0 || yy >= h) continue;
                    for (int dx = -1; dx <= 1; dx++) {
                        int xx = x + dx;
                        if (xx < 0 || xx >= w) continue;
                        int o = yy * rs + xx * ps;
                        r += b.get(o) & 255;
                        g += b.get(o + 1) & 255;
                        bl += b.get(o + 2) & 255;
                        n++;
                    }
                }
                if (n == 0) return 0;
                return 0xFF000000 | ((r / n) << 16) | ((g / n) << 8) | (bl / n);
            } catch (Exception e) {
                return 0;
            }
        }
    }

    @Override
    public int[] patch(int x, int y, int rad) {
        synchronized (lock) {
            if (current == null) return null;
            try {
                Image.Plane p = current.getPlanes()[0];
                ByteBuffer b = p.getBuffer();
                int ps = p.getPixelStride(), rs = p.getRowStride(), w = current.getWidth(), h = current.getHeight();
                int side = 2 * rad + 1;
                int[] out = new int[side * side];
                for (int dy = -rad; dy <= rad; dy++) {
                    for (int dx = -rad; dx <= rad; dx++) {
                        int xx = Math.max(0, Math.min(w - 1, x + dx)), yy = Math.max(0, Math.min(h - 1, y + dy));
                        int o = yy * rs + xx * ps;
                        out[(dy + rad) * side + dx + rad] = 0xFF000000 | ((b.get(o) & 255) << 16) | ((b.get(o + 1) & 255) << 8) | (b.get(o + 2) & 255);
                    }
                }
                return out;
            } catch (Exception e) {
                return null;
            }
        }
    }

    @Override
    public void close() {
        stopSelf();
    }

    static void stop(Context c) {
        c.stopService(new Intent(c, CaptureService.class));
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        instance = null;
        if (displayListener != null) getSystemService(DisplayManager.class).unregisterDisplayListener(displayListener);
        synchronized (lock) {
            if (current != null) current.close();
            current = null;
        }
        if (display != null) display.release();
        if (reader != null) reader.close();
        if (projection != null) {
            try {
                projection.stop();
            } catch (Exception ignored) {
            }
        }
        if (thread != null) thread.quitSafely();
        ClickService.onCapture(false);
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        // запись живёт, пока открыт кликер
    }
}
