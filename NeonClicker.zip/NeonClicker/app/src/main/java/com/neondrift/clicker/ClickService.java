package com.neondrift.clicker;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Path;
import android.hardware.HardwareBuffer;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.KeyEvent;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Toast;

import java.util.List;

/**
 * Служба спецвозможностей: только она может нажимать на экран за пользователя.
 * Держит слой с точками, исполняет сценарий и следит, какое приложение открыто.
 */
public class ClickService extends AccessibilityService implements Runner.Host {
    static volatile ClickService instance;
    static final String CHANNEL = "run";
    static final String ACTION = "com.neondrift.clicker.CONTROL";
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    Runner runner;
    Overlay overlay;
    private ShotSource shots;
    private String foreground, runPackage;
    private boolean autoPaused;
    private Prefs prefs;
    private long captureAskedAt;

    private final BroadcastReceiver control = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            String cmd = i.getStringExtra("cmd");
            if (overlay == null || cmd == null) return;
            if (cmd.equals("toggle")) overlay.togglePlay();
            else if (cmd.equals("close")) closeOverlay();
        }
    };

    // ================================================================== жизненный цикл

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        prefs = new Prefs(this);
        Theme.load(this);
        runner = new Runner(this);
        IntentFilter f = new IntentFilter(ACTION);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(control, f, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(control, f);
    }

    @Override
    public boolean onUnbind(Intent intent) {
        closeOverlay();
        instance = null;
        try {
            unregisterReceiver(control);
        } catch (Exception ignored) {
        }
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        closeOverlay();
        instance = null;
        super.onDestroy();
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        if (overlay != null) MAIN.postDelayed(() -> { if (overlay != null) overlay.onRotate(); }, 250);
    }

    /** Включена ли служба в настройках спецвозможностей. */
    static boolean enabled(Context c) {
        String s = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (s == null) return false;
        ComponentName me = new ComponentName(c, ClickService.class);
        for (String part : s.split(":")) {
            ComponentName cn = ComponentName.unflattenFromString(part);
            if (me.equals(cn)) return true;
        }
        return false;
    }

    // ================================================================== открытое приложение

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
        if (e.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED || e.getPackageName() == null) return;
        String pkg = e.getPackageName().toString();
        if (ignored(pkg)) return;
        foreground = pkg;
        if (overlay == null || runner.s == null || !runner.s.smartPause || runPackage == null) return;
        if (runner.state == Runner.RUNNING && !pkg.equals(runPackage)) {
            autoPaused = true;
            overlay.pauseBy("Пауза: открыто другое приложение");
        } else if (autoPaused && runner.state == Runner.PAUSED && pkg.equals(runPackage)) {
            autoPaused = false;
            overlay.resumeBy("Продолжаю");
        }
    }

    private boolean ignored(String pkg) {
        if (pkg.equals(getPackageName()) || pkg.equals("com.android.systemui") || pkg.equals("android")) return true;
        String ime = Settings.Secure.getString(getContentResolver(), Settings.Secure.DEFAULT_INPUT_METHOD);
        return ime != null && ime.startsWith(pkg + "/");
    }

    /** Запомнить приложение, в котором запущен сценарий (для умной паузы). */
    void markRunPackage() {
        runPackage = foreground;
        autoPaused = false;
    }

    void clearAutoPause() {
        autoPaused = false;
    }

    // ================================================================== аварийная остановка

    @Override
    protected boolean onKeyEvent(KeyEvent e) {
        if (prefs == null || !prefs.volumeStop() || overlay == null || runner.state != Runner.RUNNING) return false;
        if (e.getKeyCode() != KeyEvent.KEYCODE_VOLUME_DOWN) return false;
        if (e.getAction() == KeyEvent.ACTION_DOWN) MAIN.post(() -> { if (overlay != null) overlay.pauseBy("Остановлено кнопкой громкости"); });
        return true;
    }

    // ================================================================== слой и сценарий

    /** Открыть слой со сценарием. false — служба не включена. */
    static boolean open(Context c, String scenarioId) {
        ClickService s = instance;
        if (s == null) return false;
        Model.Scenario sc = Store.load(c, scenarioId);
        if (sc == null) return false;
        MAIN.post(() -> s.show(sc));
        return true;
    }

    private void show(Model.Scenario sc) {
        closeOverlay();
        Theme.load(this);
        overlay = new Overlay(this, sc);
        overlay.show();
        new Prefs(this).put("lastScenario", sc.id);
        notifyState();
    }

    void closeOverlay() {
        if (runner != null) runner.stop();
        if (overlay != null) {
            Overlay o = overlay;
            overlay = null;
            o.dismiss();
        }
        if (shots != null) {
            shots.close();
            shots = null;
        }
        CaptureService.stop(this);
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) nm.cancel(1);
    }

    /** Уведомление «кликер открыт» с паузой и закрытием. */
    void notifyState() {
        if (overlay == null) return;
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm == null) return;
        if (nm.getNotificationChannel(CHANNEL) == null) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Работа кликера", NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            nm.createNotificationChannel(ch);
        }
        boolean run = runner.state == Runner.RUNNING;
        Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        Notification n = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat_click)
                .setContentTitle(overlay.s.name)
                .setContentText(run ? "Кликер работает" : runner.state == Runner.PAUSED ? "На паузе" : "Настройка точек")
                .setOngoing(true)
                .setColor(Theme.ACCENT)
                .setContentIntent(PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT))
                .addAction(new Notification.Action.Builder(null, run ? "Пауза" : "Старт", control(1, "toggle")).build())
                .addAction(new Notification.Action.Builder(null, "Закрыть", control(2, "close")).build())
                .build();
        try {
            nm.notify(1, n);
        } catch (SecurityException ignored) {
        }
    }

    private PendingIntent control(int code, String cmd) {
        Intent i = new Intent(ACTION).setPackage(getPackageName()).putExtra("cmd", cmd);
        return PendingIntent.getBroadcast(this, code, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    // ================================================================== цвета экрана

    /** Источник цветов для текущего сценария (может быть ещё не готов). */
    ColorSource source() {
        if (overlay != null && overlay.s.capture == 1 && Build.VERSION.SDK_INT >= 30) return shots;
        return CaptureService.instance;
    }

    void closeShots() {
        if (shots != null) {
            shots.close();
            shots = null;
        }
    }

    boolean captureReady() {
        ColorSource s = source();
        return s != null && s.ready();
    }

    /** Включить чтение экрана: снимки (Android 11+) или запись экрана с разрешением. */
    void requestCapture() {
        if (overlay != null && overlay.s.capture == 1 && Build.VERSION.SDK_INT >= 30) {
            if (shots == null) {
                shots = new ShotSource();
                shots.start();
            }
            return;
        }
        if (CaptureService.instance != null) return;
        long now = System.currentTimeMillis();
        if (now - captureAskedAt < 6000) return; // окно разрешения уже открыто
        captureAskedAt = now;
        if (Build.VERSION.SDK_INT >= 34) toast("В окне записи выберите «Весь экран»");
        Intent i = new Intent(this, CaptureRequestActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
        try {
            startActivity(i);
        } catch (Exception e) {
            toast("Не удалось запросить запись экрана");
        }
    }

    /** Сообщение от CaptureService: запись включилась или выключилась. */
    static void onCapture(boolean ok) {
        MAIN.post(() -> {
            ClickService s = instance;
            if (s != null) s.captureAskedAt = 0;
            if (s != null && s.overlay != null) s.overlay.onCaptureChanged(ok);
        });
    }

    /** Снимки экрана через спецвозможности: без разрешения на запись, но не чаще ~3 раз в секунду. */
    final class ShotSource implements ColorSource {
        private Bitmap latest;
        private boolean running;
        private final Runnable take = this::take;

        void start() {
            running = true;
            MAIN.post(take);
        }

        private void take() {
            if (!running || Build.VERSION.SDK_INT < 30) return;
            try {
                takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(), new TakeScreenshotCallback() {
                    @Override
                    public void onSuccess(ScreenshotResult r) {
                        HardwareBuffer hb = r.getHardwareBuffer();
                        try {
                            Bitmap hw = Bitmap.wrapHardwareBuffer(hb, r.getColorSpace());
                            Bitmap sw = hw == null ? null : hw.copy(Bitmap.Config.ARGB_8888, false);
                            if (hw != null) hw.recycle();
                            synchronized (ShotSource.this) {
                                if (latest != null) latest.recycle();
                                latest = sw;
                            }
                            if (overlay != null) overlay.onCaptureChanged(true);
                        } catch (Exception | OutOfMemoryError ignored) {
                        } finally {
                            hb.close();
                        }
                        next();
                    }

                    @Override
                    public void onFailure(int code) {
                        next();
                    }
                });
            } catch (Exception e) {
                next();
            }
        }

        private void next() {
            if (!running) return;
            int hz = overlay != null ? overlay.s.checkHz : 3;
            MAIN.postDelayed(take, Math.max(350, 1000 / Math.max(1, hz)));
        }

        @Override
        public synchronized boolean ready() {
            return latest != null;
        }

        @Override
        public synchronized int color(int x, int y) {
            if (latest == null) return 0;
            int w = latest.getWidth(), h = latest.getHeight(), r = 0, g = 0, b = 0, n = 0;
            for (int dy = -1; dy <= 1; dy++) {
                for (int dx = -1; dx <= 1; dx++) {
                    int xx = x + dx, yy = y + dy;
                    if (xx < 0 || yy < 0 || xx >= w || yy >= h) continue;
                    int c = latest.getPixel(xx, yy);
                    r += (c >> 16) & 255;
                    g += (c >> 8) & 255;
                    b += c & 255;
                    n++;
                }
            }
            return n == 0 ? 0 : 0xFF000000 | ((r / n) << 16) | ((g / n) << 8) | (b / n);
        }

        @Override
        public synchronized int[] patch(int x, int y, int rad) {
            if (latest == null) return null;
            int side = 2 * rad + 1, w = latest.getWidth(), h = latest.getHeight();
            int[] out = new int[side * side];
            for (int dy = -rad; dy <= rad; dy++) {
                for (int dx = -rad; dx <= rad; dx++) {
                    out[(dy + rad) * side + dx + rad] = latest.getPixel(Math.max(0, Math.min(w - 1, x + dx)), Math.max(0, Math.min(h - 1, y + dy)));
                }
            }
            return out;
        }

        @Override
        public synchronized void close() {
            running = false;
            MAIN.removeCallbacks(take);
            if (latest != null) latest.recycle();
            latest = null;
        }
    }

    // ================================================================== Runner.Host

    @Override
    public boolean gesture(List<Logic.Stroke> strokes, Runnable done) {
        if (strokes.isEmpty()) return false;
        try {
            GestureDescription.Builder b = new GestureDescription.Builder();
            for (Logic.Stroke st : strokes) {
                Path p = new Path();
                p.moveTo(st.xs[0], st.ys[0]);
                for (int i = 1; i < st.xs.length; i++) p.lineTo(st.xs[i], st.ys[i]);
                b.addStroke(new GestureDescription.StrokeDescription(p, st.start, st.duration));
            }
            return dispatchGesture(b.build(), new GestureResultCallback() {
                @Override
                public void onCompleted(GestureDescription g) {
                    done.run();
                }

                @Override
                public void onCancelled(GestureDescription g) {
                    done.run();
                }
            }, null);
        } catch (RuntimeException e) {
            return false;
        }
    }

    @Override
    public int[] colors(Model.Trigger t) {
        ColorSource src = source();
        if (src == null || !src.ready()) return null;
        int[] c = new int[t.watches.size()];
        for (int i = 0; i < c.length; i++) {
            Model.Watch w = t.watches.get(i);
            c[i] = src.color(w.x, w.y);
        }
        return c;
    }

    int[] realSize() {
        DisplayMetrics dm = new DisplayMetrics();
        getSystemService(WindowManager.class).getDefaultDisplay().getRealMetrics(dm);
        return new int[]{dm.widthPixels, dm.heightPixels};
    }

    @Override
    public int screenW() {
        return realSize()[0];
    }

    @Override
    public int screenH() {
        return realSize()[1];
    }

    @Override
    public int maxStrokes() {
        return GestureDescription.getMaxStrokeCount();
    }

    @Override
    public void onChanged() {
        if (overlay != null) overlay.refresh();
        notifyState();
    }

    @Override
    public void onFinished(String why) {
        if (overlay != null) overlay.onFinished(why);
    }
}
