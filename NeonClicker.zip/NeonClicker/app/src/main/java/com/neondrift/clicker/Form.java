package com.neondrift.clicker;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.IntFunction;
import java.util.function.LongConsumer;
import java.util.function.LongFunction;
import java.util.function.LongUnaryOperator;

/** Строительные блоки форм: подписи, чипы, «−/+» с удержанием, переключатели, ползунки, кнопки. */
final class Form {
    final Context c;
    final Ui ui;
    final LinearLayout box;
    private static final Handler H = new Handler(Looper.getMainLooper());

    Form(Context c, Ui ui, LinearLayout box) {
        this.c = c;
        this.ui = ui;
        this.box = box;
    }

    TextView section(String s) {
        TextView t = ui.label(s);
        box.addView(t, Ui.margins(Ui.WRAP, Ui.WRAP, ui.dp(2), ui.dp(16), 0, ui.dp(6)));
        return t;
    }

    TextView note(String s) {
        TextView t = ui.text(s, 12.5f, Theme.MUTED, false);
        t.setLineSpacing(0, 1.25f);
        box.addView(t, Ui.margins(Ui.MATCH, Ui.WRAP, ui.dp(2), ui.dp(4), 0, ui.dp(2)));
        return t;
    }

    /** Ряд чипов с подписью. */
    LinearLayout chips(String label, String[] names, int selected, IntConsumer pick) {
        if (label != null) box.addView(ui.text(label, 13.5f, Theme.TEXT, false), Ui.margins(Ui.WRAP, Ui.WRAP, ui.dp(2), ui.dp(10), 0, ui.dp(6)));
        HorizontalScrollView hs = new HorizontalScrollView(c);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = ui.row();
        TextView[] views = new TextView[names.length];
        for (int i = 0; i < names.length; i++) {
            int k = i;
            views[i] = ui.chip(names[i], i == selected, v -> {
                for (int j = 0; j < views.length; j++) ui.styleChip(views[j], j == k);
                pick.accept(k);
            });
            LinearLayout.LayoutParams lp = Ui.lp(Ui.WRAP, Ui.WRAP);
            lp.rightMargin = ui.dp(8);
            row.addView(views[i], lp);
        }
        hs.addView(row);
        box.addView(hs, Ui.lp(Ui.MATCH, Ui.WRAP));
        return row;
    }

    /** «Подпись  [−] значение [+]». Удержание кнопки повторяет шаг всё быстрее. */
    TextView stepper(String label, long value, long min, long max, LongFunction<String> fmt,
                     LongUnaryOperator up, LongUnaryOperator down, LongConsumer set) {
        LinearLayout row = ui.row();
        row.setPadding(ui.dp(2), ui.dp(6), 0, ui.dp(6));
        TextView l = ui.text(label, 13.5f, Theme.TEXT, false);
        row.addView(l, Ui.lp(0, Ui.WRAP, 1f));
        long[] v = {Math.max(min, Math.min(max, value))};
        TextView val = ui.text(fmt.apply(v[0]), 14, Theme.ACCENT, true);
        val.setGravity(Gravity.CENTER);
        View minus = repeatButton("minus", () -> {
            long nv = Math.max(min, down.applyAsLong(v[0]));
            if (nv == v[0]) return;
            v[0] = nv;
            val.setText(fmt.apply(nv));
            set.accept(nv);
        });
        View plus = repeatButton("plus", () -> {
            long nv = Math.min(max, up.applyAsLong(v[0]));
            if (nv == v[0]) return;
            v[0] = nv;
            val.setText(fmt.apply(nv));
            set.accept(nv);
        });
        row.addView(minus);
        row.addView(val, Ui.lp(ui.dp(78), Ui.WRAP));
        row.addView(plus);
        box.addView(row, Ui.lp(Ui.MATCH, Ui.WRAP));
        return val;
    }

    /** Простой счётчик с шагом 1. */
    TextView counter(String label, int value, int min, int max, IntFunction<String> fmt, IntConsumer set) {
        return stepper(label, value, min, max, x -> fmt.apply((int) x), x -> x + 1, x -> x - 1, x -> set.accept((int) x));
    }

    /** Паузы и длительности: шаг зависит от величины (1 мс … 1 мин). */
    TextView duration(String label, long value, long min, long max, LongConsumer set) {
        return stepper(label, value, min, max, Logic::ms, Logic::stepUp, Logic::stepDown, set);
    }

    @SuppressLint("ClickableViewAccessibility")
    private View repeatButton(String icon, Runnable step) {
        ImageView b = new ImageView(c);
        b.setImageDrawable(new Glyph(icon, Theme.TEXT));
        int p = ui.dp(10);
        b.setPadding(p, p, p, p);
        b.setBackground(Ui.ripple(Ui.oval(Theme.SURFACE2), Ui.oval(0xFFFFFFFF)));
        b.setLayoutParams(new LinearLayout.LayoutParams(ui.dp(38), ui.dp(38)));
        b.setContentDescription(icon.equals("plus") ? "Больше" : "Меньше");
        Runnable[] rep = new Runnable[1];
        int[] count = new int[1];
        rep[0] = () -> {
            step.run();
            count[0]++;
            H.postDelayed(rep[0], count[0] > 12 ? 30 : count[0] > 4 ? 70 : 130);
        };
        b.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    v.setPressed(true);
                    step.run();
                    count[0] = 0;
                    H.postDelayed(rep[0], 420);
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    v.setPressed(false);
                    H.removeCallbacks(rep[0]);
                    return true;
                default:
                    return true;
            }
        });
        return b;
    }

    Switch toggle(String title, String sub, boolean checked, Consumer<Boolean> changed) {
        LinearLayout row = ui.row();
        row.setPadding(ui.dp(2), ui.dp(8), 0, ui.dp(8));
        LinearLayout tx = ui.col();
        tx.addView(ui.text(title, 14, Theme.TEXT, false));
        if (sub != null) {
            TextView s = ui.text(sub, 12, Theme.MUTED, false);
            s.setLineSpacing(0, 1.2f);
            tx.addView(s, Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(3), 0, 0));
        }
        row.addView(tx, Ui.lp(0, Ui.WRAP, 1f));
        Switch s = new Switch(c);
        s.setChecked(checked);
        int[][] states = {{android.R.attr.state_checked}, {}};
        s.setThumbTintList(new ColorStateList(states, new int[]{Theme.ACCENT, 0xFFB8B0D0}));
        s.setTrackTintList(new ColorStateList(states, new int[]{Theme.alpha(Theme.ACCENT, 120), 0xFF3A3352}));
        s.setOnCheckedChangeListener((b, on) -> changed.accept(on));
        row.addView(s);
        row.setOnClickListener(v -> s.toggle());
        box.addView(row, Ui.lp(Ui.MATCH, Ui.WRAP));
        return s;
    }

    /** Ползунок с подписью значения. */
    SeekBar slider(String label, int max, int value, IntFunction<String> fmt, IntConsumer set) {
        LinearLayout head = ui.row();
        head.setPadding(ui.dp(2), ui.dp(8), 0, 0);
        head.addView(ui.text(label, 13.5f, Theme.TEXT, false), Ui.lp(0, Ui.WRAP, 1f));
        TextView val = ui.text(fmt.apply(value), 14, Theme.ACCENT, true);
        head.addView(val);
        box.addView(head, Ui.lp(Ui.MATCH, Ui.WRAP));
        SeekBar sb = new SeekBar(c);
        sb.setMax(max);
        sb.setProgress(value);
        sb.setProgressTintList(ColorStateList.valueOf(Theme.ACCENT));
        sb.setThumbTintList(ColorStateList.valueOf(Theme.ACCENT));
        sb.setProgressBackgroundTintList(ColorStateList.valueOf(0x55FFFFFF));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean user) {
                val.setText(fmt.apply(p));
                if (user) set.accept(p);
            }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });
        box.addView(sb, Ui.lp(Ui.MATCH, Ui.WRAP));
        return sb;
    }

    TextView button(String s, boolean primary, Runnable r) {
        TextView b = ui.button(s, primary, v -> r.run());
        b.setPadding(ui.dp(14), ui.dp(11), ui.dp(14), ui.dp(11));
        box.addView(b, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(8), 0, 0));
        return b;
    }

    /** Два действия в ряд. */
    LinearLayout buttons(String a, boolean aPrimary, Runnable ra, String b, boolean bPrimary, Runnable rb) {
        LinearLayout row = ui.row();
        TextView x = ui.button(a, aPrimary, v -> ra.run());
        x.setPadding(ui.dp(10), ui.dp(11), ui.dp(10), ui.dp(11));
        row.addView(x, Ui.lp(0, Ui.WRAP, 1f));
        TextView y = ui.button(b, bPrimary, v -> rb.run());
        y.setPadding(ui.dp(10), ui.dp(11), ui.dp(10), ui.dp(11));
        LinearLayout.LayoutParams lp = Ui.lp(0, Ui.WRAP, 1f);
        lp.leftMargin = ui.dp(8);
        row.addView(y, lp);
        box.addView(row, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(8), 0, 0));
        return row;
    }
}
