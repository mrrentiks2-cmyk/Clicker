package com.neondrift.clicker;

/** Откуда берутся цвета экрана: запись экрана или снимки через спецвозможности. */
interface ColorSource {
    boolean ready();

    /** Средний цвет квадрата 3×3 вокруг точки (0xFFRRGGBB) или 0, если кадра ещё нет. */
    int color(int x, int y);

    /** Пиксели квадрата (2r+1)² для лупы или null. */
    int[] patch(int x, int y, int r);

    void close();
}
