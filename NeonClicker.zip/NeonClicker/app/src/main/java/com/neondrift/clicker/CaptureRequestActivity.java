package com.neondrift.clicker;

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.widget.Toast;

/** Прозрачный экран: спрашивает разрешение на запись экрана и запускает CaptureService. */
public class CaptureRequestActivity extends Activity {
    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        if (saved != null) return;
        try {
            MediaProjectionManager mpm = getSystemService(MediaProjectionManager.class);
            startActivityForResult(mpm.createScreenCaptureIntent(), 1);
        } catch (Exception e) {
            ClickService.onCapture(false);
            finish();
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res == RESULT_OK && data != null) {
            Intent svc = new Intent(this, CaptureService.class).putExtra("code", res).putExtra("data", data);
            startForegroundService(svc);
        } else {
            Toast.makeText(this, "Без записи экрана клики по цвету не работают", Toast.LENGTH_LONG).show();
            ClickService.onCapture(false);
        }
        finish();
        overridePendingTransition(0, 0);
    }
}
