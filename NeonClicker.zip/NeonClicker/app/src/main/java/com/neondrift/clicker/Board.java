package com.neondrift.clicker;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;

import java.util.List;

/**
 * Слой поверх экрана: точки нажатия, свайпы и точки проверки цвета. Их можно перетаскивать.
 * У всех меток пустой центр — так запись экрана видит настоящий цвет под точкой, а не саму метку.
 */
@SuppressLint("ViewConstructor")
final class Board extends View {
    interface Listener {
        void onSelect(Object item);
        void onMoved(Object item);
        void onTapEmpty();
        int[] patch(int x, int y, int r);
    }

    static final int[] TRIGGER_COLORS = {0xFF00E5FF, 0xFF8CFF5A, 0xFFFF8A3D, 0xFFB57BFF, 0xFFFFD447, 0xFF5C8DFF, 0xFFFF4F9A};
    static final String LETTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

    private final Ui ui;
    private final Listener listener;
    Model.Scenario s;
    Object selected;
    boolean running, hidden;
    /** Текущие цвета в точках проверки (по триггерам) и выполнено ли условие. */
    int[][] live;
    boolean[] cond;
    float scale = 1f;

    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG), fill = new Paint(Paint.ANTI_ALIAS_FLAG),
            text = new Paint(Paint.ANTI_ALIAS_FLAG), line = new Paint(Paint.ANTI_ALIAS_FLAG), grid = new Paint();
    private final RectF r = new RectF();
    private final Path path = new Path();
    private final int[] loc = new int[2];

    // перетаскивание
    private Object drag;
    private boolean dragEnd, moved;
    private float grabDx, grabDy, downX, downY;
    private final int slop;

    Board(Context c, Ui ui, Listener l) {
        super(c);
        this.ui = ui;
        this.listener = l;
        ring.setStyle(Paint.Style.STROKE);
        fill.setStyle(Paint.Style.FILL);
        text.setTypeface(Typeface.DEFAULT_BOLD);
        text.setTextAlign(Paint.Align.CENTER);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
        grid.setStyle(Paint.Style.FILL);
        slop = ViewConfiguration.get(c).getScaledTouchSlop();
    }

    private float dp(float v) {
        return v * ui.density * scale;
    }

    /** Сдвиг окна относительно экрана (обычно 0). */
    private int ox() {
        getLocationOnScreen(loc);
        return loc[0];
    }

    private int oy() {
        return loc[1];
    }

    static int triggerColor(int i) {
        return TRIGGER_COLORS[i % TRIGGER_COLORS.length];
    }

    static String letter(int i) {
        return i < LETTERS.length() ? String.valueOf(LETTERS.charAt(i)) : "T" + (i + 1);
    }

    // ================================================================== рисование

    @Override
    protected void onDraw(Canvas c) {
        if (s == null || hidden) return;
        float ox = ox(), oy = oy();
        c.save();
        c.translate(-ox, -oy);
        int alpha = running ? 150 : 255;
        // связи «точки проверки → точка нажатия»
        for (int ti = 0; ti < s.triggers.size(); ti++) {
            Model.Trigger t = s.triggers.get(ti);
            if (t.actions.isEmpty()) continue;
            Model.Target a = t.actions.get(0);
            line.setColor(Theme.alpha(triggerColor(ti), t.enabled ? 110 * alpha / 255 : 40));
            line.setStrokeWidth(dp(1.5f));
            line.setPathEffect(new DashPathEffect(new float[]{dp(5), dp(5)}, 0));
            // линия начинается у края кольца: центр точки проверки должен оставаться чистым
            float ro = dp(17), ra = dp(23);
            for (Model.Watch w : t.watches) {
                float dx = a.x - w.x, dy = a.y - w.y, len = (float) Math.hypot(dx, dy);
                if (len <= ro + ra) continue;
                float ux = dx / len, uy = dy / len;
                c.drawLine(w.x + ux * ro, w.y + uy * ro, a.x - ux * ra, a.y - uy * ra, line);
            }
            line.setPathEffect(null);
        }
        for (int i = 0; i < s.targets.size(); i++) {
            Model.Target t = s.targets.get(i);
            drawTarget(c, t, String.valueOf(i + 1), Theme.ACCENT, alpha);
        }
        for (int ti = 0; ti < s.triggers.size(); ti++) {
            Model.Trigger t = s.triggers.get(ti);
            int col = t.enabled ? triggerColor(ti) : 0xFF8A8399;
            for (int ai = 0; ai < t.actions.size(); ai++) {
                drawTarget(c, t.actions.get(ai), letter(ti) + (t.actions.size() > 1 ? String.valueOf(ai + 1) : "") + " →", col, alpha);
            }
            for (int wi = 0; wi < t.watches.size(); wi++) {
                int[] lv = live != null && ti < live.length ? live[ti] : null;
                Integer now = lv != null && wi < lv.length && lv[wi] != 0 ? lv[wi] : null;
                drawWatch(c, t, t.watches.get(wi), letter(ti) + (wi + 1), col, now, alpha);
            }
            if (cond != null && ti < cond.length && cond[ti] && !t.actions.isEmpty()) {
                Model.Target a = t.actions.get(0);
                ring.setColor(Theme.alpha(0xFF3DFF8C, 200));
                ring.setStrokeWidth(dp(3));
                c.drawCircle(a.x, a.y, dp(30), ring);
            }
        }
        if (drag != null && moved && !running) drawLoupe(c);
        c.restore();
    }

    private void drawTarget(Canvas c, Model.Target t, String label, int col, int alpha) {
        float R = dp(21);
        boolean sel = selected == t;
        if (t.type == Model.SWIPE) {
            line.setColor(Theme.alpha(col, 200 * alpha / 255));
            line.setStrokeWidth(dp(3));
            float len = (float) Math.hypot(t.x2 - t.x, t.y2 - t.y);
            if (len > R) c.drawLine(t.x + (t.x2 - t.x) * R / len, t.y + (t.y2 - t.y) * R / len, t.x2, t.y2, line);
            // стрелка
            double ang = Math.atan2(t.y2 - t.y, t.x2 - t.x);
            float ah = dp(14);
            path.reset();
            path.moveTo(t.x2, t.y2);
            path.lineTo((float) (t.x2 - ah * Math.cos(ang - 0.45)), (float) (t.y2 - ah * Math.sin(ang - 0.45)));
            path.moveTo(t.x2, t.y2);
            path.lineTo((float) (t.x2 - ah * Math.cos(ang + 0.45)), (float) (t.y2 - ah * Math.sin(ang + 0.45)));
            c.drawPath(path, line);
            ring.setColor(Theme.alpha(col, alpha));
            ring.setStrokeWidth(dp(2.5f));
            c.drawCircle(t.x2, t.y2, dp(13), ring);
        }
        if (sel) {
            ring.setColor(Theme.alpha(col, 70));
            ring.setStrokeWidth(dp(8));
            c.drawCircle(t.x, t.y, R + dp(5), ring);
        }
        // тёмная подложка под кольцо, чтобы было видно на любом фоне
        ring.setColor(Theme.alpha(0xFF000000, 120 * alpha / 255));
        ring.setStrokeWidth(dp(6));
        c.drawCircle(t.x, t.y, R, ring);
        ring.setColor(Theme.alpha(col, alpha));
        ring.setStrokeWidth(dp(3));
        c.drawCircle(t.x, t.y, R, ring);
        if (t.type == Model.DOUBLE) {
            ring.setStrokeWidth(dp(2));
            c.drawCircle(t.x, t.y, R - dp(6), ring);
        }
        // перекрестие с пустым центром
        line.setColor(Theme.alpha(col, alpha));
        line.setStrokeWidth(dp(2));
        float a = dp(9), b = dp(15);
        c.drawLine(t.x - b, t.y, t.x - a, t.y, line);
        c.drawLine(t.x + a, t.y, t.x + b, t.y, line);
        c.drawLine(t.x, t.y - b, t.x, t.y - a, line);
        c.drawLine(t.x, t.y + a, t.x, t.y + b, line);
        String l = label;
        if (t.type == Model.LONG) l += " · " + Logic.ms(t.holdMs);
        if (t.repeat > 1) l += " ×" + t.repeat;
        pill(c, l, t.x + R * 0.7f, t.y - R * 1.05f, col, alpha);
    }

    private void drawWatch(Canvas c, Model.Trigger t, Model.Watch w, String label, int col, Integer now, int alpha) {
        boolean sel = selected == w;
        float hole = dp(7), band = dp(5), outer = dp(16);
        if (sel) {
            ring.setColor(Theme.alpha(col, 70));
            ring.setStrokeWidth(dp(8));
            c.drawCircle(w.x, w.y, outer + dp(5), ring);
        }
        // образец цвета — кольцо вокруг пустого центра
        ring.setStrokeWidth(band);
        ring.setColor(w.picked ? (w.color | 0xFF000000) : 0xFF6C6488);
        c.drawCircle(w.x, w.y, hole + band / 2, ring);
        ring.setStrokeWidth(dp(1));
        ring.setColor(0xCC000000);
        c.drawCircle(w.x, w.y, hole, ring);
        ring.setStrokeWidth(dp(2.5f));
        ring.setColor(Theme.alpha(col, alpha));
        c.drawCircle(w.x, w.y, outer, ring);
        if (w.invert) { // «≠» — перечёркнуто, но только по кольцу: центр остаётся чистым
            line.setColor(Theme.alpha(0xFFFF5C7A, alpha));
            line.setStrokeWidth(dp(2.5f));
            float k = 0.7071f, r1 = hole + dp(1.5f), r2 = outer + dp(3);
            c.drawLine(w.x - r2 * k, w.y + r2 * k, w.x - r1 * k, w.y + r1 * k, line);
            c.drawLine(w.x + r1 * k, w.y - r1 * k, w.x + r2 * k, w.y - r2 * k, line);
        }
        // текущий цвет и совпадение
        if (now != null) {
            boolean ok = t.mode == Model.SAME || ((Logic.diff(now, w.color) <= Logic.limit(t.tolerance)) != w.invert);
            fill.setColor(now | 0xFF000000);
            float bx = w.x + outer * 0.85f, by = w.y + outer * 0.85f, br = dp(6);
            c.drawCircle(bx, by, br, fill);
            ring.setStrokeWidth(dp(2));
            ring.setColor(t.mode == Model.SAME ? 0xFFFFFFFF : ok ? 0xFF3DFF8C : 0xFFFF5C7A);
            c.drawCircle(bx, by, br, ring);
        }
        pill(c, label + (w.invert ? "≠" : ""), w.x + outer * 0.6f, w.y - outer * 1.25f, col, alpha);
    }

    private void pill(Canvas c, String s, float x, float y, int col, int alpha) {
        text.setTextSize(dp(11));
        float w = text.measureText(s) + dp(10), h = dp(17);
        // не вылезать за края экрана
        float right = getWidth() + loc[0] - dp(2), top = loc[1] + dp(2);
        if (x + w > right) x = right - w;
        if (y - h / 2 < top) y = top + h / 2;
        r.set(x, y - h / 2, x + w, y + h / 2);
        fill.setColor(Theme.alpha(col, alpha));
        c.drawRoundRect(r, h / 2, h / 2, fill);
        text.setColor(Theme.alpha(0xFF0A0812, alpha));
        Paint.FontMetrics fm = text.getFontMetrics();
        c.drawText(s, x + w / 2, y - (fm.ascent + fm.descent) / 2, text);
    }

    /** Лупа при перетаскивании: увеличенные пиксели под точкой и координаты. */
    private void drawLoupe(Canvas c) {
        int px, py;
        if (drag instanceof Model.Watch) {
            px = ((Model.Watch) drag).x;
            py = ((Model.Watch) drag).y;
        } else {
            Model.Target t = (Model.Target) drag;
            px = dragEnd ? t.x2 : t.x;
            py = dragEnd ? t.y2 : t.y;
        }
        int rad = 5;
        int[] patch = listener.patch(px, py, rad);
        float size = dp(118), cell = size / (2 * rad + 1);
        float lx = px - size / 2, ly = py - size - dp(56);
        if (ly < dp(8) + oy()) ly = py + dp(56);
        lx = Math.max(dp(8) + ox(), Math.min(getWidth() + ox() - size - dp(8), lx));
        r.set(lx - dp(3), ly - dp(3), lx + size + dp(3), ly + size + dp(26));
        fill.setColor(0xEE0A0812);
        c.drawRoundRect(r, dp(10), dp(10), fill);
        if (patch != null) {
            for (int yy = 0; yy <= 2 * rad; yy++) {
                for (int xx = 0; xx <= 2 * rad; xx++) {
                    grid.setColor(patch[yy * (2 * rad + 1) + xx] | 0xFF000000);
                    c.drawRect(lx + xx * cell, ly + yy * cell, lx + (xx + 1) * cell, ly + (yy + 1) * cell, grid);
                }
            }
            ring.setColor(0xFFFFFFFF);
            ring.setStrokeWidth(dp(1.5f));
            c.drawRect(lx + rad * cell, ly + rad * cell, lx + (rad + 1) * cell, ly + (rad + 1) * cell, ring);
        } else {
            text.setTextSize(dp(10));
            text.setColor(Theme.MUTED);
            c.drawText("цвета появятся,", lx + size / 2, ly + size / 2 - dp(6), text);
            c.drawText("когда включена запись", lx + size / 2, ly + size / 2 + dp(8), text);
        }
        text.setTextSize(dp(11));
        text.setColor(Theme.TEXT);
        String info = px + ", " + py + (patch != null ? "  " + Model.hex(patch[rad * (2 * rad + 1) + rad]) : "");
        c.drawText(info, lx + size / 2, ly + size + dp(17), text);
    }

    // ================================================================== касания

    /** Ближайший элемент к точке экрана. */
    private Object hit(float x, float y, boolean[] end) {
        float best = dp(34);
        Object found = null;
        end[0] = false;
        for (int ti = s.triggers.size() - 1; ti >= 0; ti--) {
            Model.Trigger t = s.triggers.get(ti);
            for (Model.Watch w : t.watches) {
                float d = (float) Math.hypot(w.x - x, w.y - y);
                if (d < best) { best = d; found = w; end[0] = false; }
            }
        }
        for (Model.Target t : allTargets()) {
            if (t.type == Model.SWIPE) {
                float d2 = (float) Math.hypot(t.x2 - x, t.y2 - y);
                if (d2 < best) { best = d2; found = t; end[0] = true; }
            }
            float d = (float) Math.hypot(t.x - x, t.y - y);
            if (d < best) { best = d; found = t; end[0] = false; }
        }
        return found;
    }

    private java.util.ArrayList<Model.Target> allTargets() {
        java.util.ArrayList<Model.Target> out = new java.util.ArrayList<>(s.targets);
        for (Model.Trigger t : s.triggers) out.addAll(t.actions);
        return out;
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (s == null || running) return false;
        getLocationOnScreen(loc);
        float x = e.getX() + loc[0], y = e.getY() + loc[1];
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                boolean[] end = new boolean[1];
                drag = hit(x, y, end);
                dragEnd = end[0];
                moved = false;
                downX = x;
                downY = y;
                if (drag instanceof Model.Watch) {
                    grabDx = ((Model.Watch) drag).x - x;
                    grabDy = ((Model.Watch) drag).y - y;
                } else if (drag instanceof Model.Target) {
                    Model.Target t = (Model.Target) drag;
                    grabDx = (dragEnd ? t.x2 : t.x) - x;
                    grabDy = (dragEnd ? t.y2 : t.y) - y;
                }
                return true;
            }
            case MotionEvent.ACTION_MOVE:
                if (drag == null) return true;
                if (!moved && Math.hypot(x - downX, y - downY) < slop) return true;
                moved = true;
                int nx = Math.round(Math.max(0, Math.min(getWidth() + loc[0] - 1, x + grabDx)));
                int ny = Math.round(Math.max(0, Math.min(getHeight() + loc[1] - 1, y + grabDy)));
                if (drag instanceof Model.Watch) {
                    ((Model.Watch) drag).x = nx;
                    ((Model.Watch) drag).y = ny;
                } else {
                    Model.Target t = (Model.Target) drag;
                    if (dragEnd) {
                        t.x2 = nx;
                        t.y2 = ny;
                    } else {
                        // свайп двигается целиком
                        if (t.type == Model.SWIPE) {
                            t.x2 += nx - t.x;
                            t.y2 += ny - t.y;
                        }
                        t.x = nx;
                        t.y = ny;
                    }
                }
                invalidate();
                return true;
            case MotionEvent.ACTION_UP: {
                Object d = drag;
                drag = null;
                if (d == null) listener.onTapEmpty();
                else if (moved) listener.onMoved(d);
                else listener.onSelect(d);
                invalidate();
                return true;
            }
            case MotionEvent.ACTION_CANCEL:
                drag = null;
                invalidate();
                return true;
            default:
                return true;
        }
    }

    /** Есть ли что-то под точкой (для подсказок). */
    boolean empty() {
        return s == null || (s.targets.isEmpty() && s.triggers.isEmpty());
    }

    static List<Model.Target> targetsOf(Model.Scenario s) {
        java.util.ArrayList<Model.Target> out = new java.util.ArrayList<>(s.targets);
        for (Model.Trigger t : s.triggers) out.addAll(t.actions);
        return out;
    }
}
