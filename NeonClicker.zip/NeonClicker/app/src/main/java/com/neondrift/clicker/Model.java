package com.neondrift.clicker;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Сценарий кликера: точки «по кругу» и триггеры по цвету. Координаты — в пикселях экрана
 * (того размера, при котором сценарий создан; при другом размере всё пропорционально пересчитывается).
 * Без зависимостей от Android — проверяется тестами.
 */
final class Model {
    private Model() {}

    // типы нажатий
    static final int TAP = 0, DOUBLE = 1, LONG = 2, SWIPE = 3;
    static final String[] TYPE_NAMES = {"Нажатие", "Двойное", "Долгое", "Свайп"};

    // режимы триггера
    static final int MATCH = 0, SAME = 1;
    // когда срабатывать
    static final int ONCE = 0, REPEAT = 1;

    /** Точка нажатия (или свайп от x,y до x2,y2). */
    static final class Target {
        int x, y, x2, y2;
        int type = TAP;
        int holdMs = 600;      // для долгого нажатия и свайпа
        int delayMs = 100;     // пауза после
        int repeat = 1;        // сколько раз подряд

        Target copy() {
            Target t = new Target();
            t.x = x; t.y = y; t.x2 = x2; t.y2 = y2;
            t.type = type; t.holdMs = holdMs; t.delayMs = delayMs; t.repeat = repeat;
            return t;
        }
    }

    /** Точка проверки цвета. */
    static final class Watch {
        int x, y;
        int color = 0xFFFFFFFF;
        boolean picked;      // цвет взят с экрана
        boolean invert;      // условие «цвет НЕ такой»

        Watch copy() {
            Watch w = new Watch();
            w.x = x; w.y = y; w.color = color; w.picked = picked; w.invert = invert;
            return w;
        }
    }

    /** Триггер: если цвета в точках проверки совпали — нажать в своих точках. */
    static final class Trigger {
        boolean enabled = true;
        int mode = MATCH;
        int need = 0;          // сколько точек должно совпасть; 0 — все
        int tolerance = 10;    // допуск, %
        int holdMs = 0;        // условие должно держаться столько
        int fire = ONCE;
        int cooldownMs = 500;  // пауза между срабатываниями (у «пока держится» — интервал)
        boolean together;      // все точки нажатия одновременно (мультитач)
        final List<Watch> watches = new ArrayList<>();
        final List<Target> actions = new ArrayList<>();

        /** Сколько точек нужно на самом деле (0 → все, не больше числа точек). */
        int needed() {
            int n = watches.size();
            if (need <= 0 || need > n) return n;
            return need;
        }

        Trigger copy() {
            Trigger t = new Trigger();
            t.enabled = enabled; t.mode = mode; t.need = need; t.tolerance = tolerance; t.holdMs = holdMs;
            t.fire = fire; t.cooldownMs = cooldownMs; t.together = together;
            for (Watch w : watches) t.watches.add(w.copy());
            for (Target a : actions) t.actions.add(a.copy());
            return t;
        }
    }

    static final class Scenario {
        String id = UUID.randomUUID().toString();
        String name = "Сценарий";
        long created, edited, lastRun;
        int screenW, screenH;
        int cycles;            // 0 — бесконечно
        long stopAfterMs;      // 0 — без ограничения
        int jitterPct;         // случайная добавка к паузам, ±%
        int jitterPx;          // случайный сдвиг точки нажатия, px
        int pressMs = 30;      // длительность обычного нажатия
        int pressJitterMs;     // случайная добавка к длительности нажатия
        int checkHz = 20;      // как часто проверять цвета
        int capture;           // 0 — запись экрана (быстро), 1 — снимки экрана (Android 11+)
        boolean smartPause = true;
        final List<Target> targets = new ArrayList<>();
        final List<Trigger> triggers = new ArrayList<>();

        int watchCount() {
            int n = 0;
            for (Trigger t : triggers) n += t.watches.size();
            return n;
        }

        Scenario copy() {
            Scenario s = fromJson(toJson(this));
            s.id = UUID.randomUUID().toString();
            return s;
        }

        /** Пересчитать координаты под другой размер экрана (поворот, другой телефон). */
        void scaleTo(int w, int h) {
            if (screenW <= 0 || screenH <= 0 || w <= 0 || h <= 0 || (w == screenW && h == screenH)) {
                if (screenW <= 0) { screenW = w; screenH = h; }
                return;
            }
            float kx = w / (float) screenW, ky = h / (float) screenH;
            for (Target t : targets) scale(t, kx, ky);
            for (Trigger tr : triggers) {
                for (Target t : tr.actions) scale(t, kx, ky);
                for (Watch wt : tr.watches) {
                    wt.x = Math.round(wt.x * kx);
                    wt.y = Math.round(wt.y * ky);
                }
            }
            screenW = w;
            screenH = h;
        }

        private static void scale(Target t, float kx, float ky) {
            t.x = Math.round(t.x * kx);
            t.y = Math.round(t.y * ky);
            t.x2 = Math.round(t.x2 * kx);
            t.y2 = Math.round(t.y2 * ky);
        }
    }

    // ================================================================== JSON

    static String toJson(Scenario s) {
        return Json.write(map(s));
    }

    static Map<String, Object> map(Scenario s) {
        LinkedHashMap<String, Object> m = new LinkedHashMap<>();
        m.put("app", "Neon Clicker");
        m.put("format", 1L);
        m.put("id", s.id);
        m.put("name", s.name);
        m.put("created", s.created);
        m.put("edited", s.edited);
        m.put("lastRun", s.lastRun);
        m.put("screenW", (long) s.screenW);
        m.put("screenH", (long) s.screenH);
        m.put("cycles", (long) s.cycles);
        m.put("stopAfterMs", s.stopAfterMs);
        m.put("jitterPct", (long) s.jitterPct);
        m.put("jitterPx", (long) s.jitterPx);
        m.put("pressMs", (long) s.pressMs);
        m.put("pressJitterMs", (long) s.pressJitterMs);
        m.put("checkHz", (long) s.checkHz);
        m.put("capture", (long) s.capture);
        m.put("smartPause", s.smartPause);
        ArrayList<Object> ts = new ArrayList<>();
        for (Target t : s.targets) ts.add(target(t));
        m.put("targets", ts);
        ArrayList<Object> trs = new ArrayList<>();
        for (Trigger t : s.triggers) {
            LinkedHashMap<String, Object> tm = new LinkedHashMap<>();
            tm.put("enabled", t.enabled);
            tm.put("mode", (long) t.mode);
            tm.put("need", (long) t.need);
            tm.put("tolerance", (long) t.tolerance);
            tm.put("holdMs", (long) t.holdMs);
            tm.put("fire", (long) t.fire);
            tm.put("cooldownMs", (long) t.cooldownMs);
            tm.put("together", t.together);
            ArrayList<Object> ws = new ArrayList<>();
            for (Watch w : t.watches) {
                LinkedHashMap<String, Object> wm = new LinkedHashMap<>();
                wm.put("x", (long) w.x);
                wm.put("y", (long) w.y);
                wm.put("color", String.format("#%08X", w.color));
                wm.put("picked", w.picked);
                wm.put("invert", w.invert);
                ws.add(wm);
            }
            tm.put("watches", ws);
            ArrayList<Object> as = new ArrayList<>();
            for (Target a : t.actions) as.add(target(a));
            tm.put("actions", as);
            trs.add(tm);
        }
        m.put("triggers", trs);
        return m;
    }

    private static Map<String, Object> target(Target t) {
        LinkedHashMap<String, Object> m = new LinkedHashMap<>();
        m.put("x", (long) t.x);
        m.put("y", (long) t.y);
        m.put("x2", (long) t.x2);
        m.put("y2", (long) t.y2);
        m.put("type", (long) t.type);
        m.put("holdMs", (long) t.holdMs);
        m.put("delayMs", (long) t.delayMs);
        m.put("repeat", (long) t.repeat);
        return m;
    }

    @SuppressWarnings("unchecked")
    static Scenario fromJson(String json) {
        Object o = Json.parse(json);
        if (!(o instanceof Map)) throw new IllegalArgumentException("не сценарий");
        Map<String, Object> m = (Map<String, Object>) o;
        if (!m.containsKey("targets") && !m.containsKey("triggers")) throw new IllegalArgumentException("не сценарий Neon Clicker");
        Scenario s = new Scenario();
        s.id = Json.str(m, "id", s.id);
        s.name = Json.str(m, "name", s.name);
        s.created = Json.num(m, "created", 0);
        s.edited = Json.num(m, "edited", 0);
        s.lastRun = Json.num(m, "lastRun", 0);
        s.screenW = (int) Json.num(m, "screenW", 0);
        s.screenH = (int) Json.num(m, "screenH", 0);
        s.cycles = clamp(Json.num(m, "cycles", 0), 0, 1_000_000);
        s.stopAfterMs = Math.max(0, Json.num(m, "stopAfterMs", 0));
        s.jitterPct = clamp(Json.num(m, "jitterPct", 0), 0, 90);
        s.jitterPx = clamp(Json.num(m, "jitterPx", 0), 0, 300);
        s.pressMs = clamp(Json.num(m, "pressMs", 30), 1, 5000);
        s.pressJitterMs = clamp(Json.num(m, "pressJitterMs", 0), 0, 2000);
        s.checkHz = clamp(Json.num(m, "checkHz", 20), 1, 60);
        s.capture = clamp(Json.num(m, "capture", 0), 0, 1);
        s.smartPause = !m.containsKey("smartPause") || Json.bool(m, "smartPause");
        for (Object t : Json.list(m, "targets")) if (t instanceof Map) s.targets.add(target((Map<String, Object>) t));
        for (Object to : Json.list(m, "triggers")) {
            if (!(to instanceof Map)) continue;
            Map<String, Object> tm = (Map<String, Object>) to;
            Trigger t = new Trigger();
            t.enabled = !tm.containsKey("enabled") || Json.bool(tm, "enabled");
            t.mode = clamp(Json.num(tm, "mode", 0), 0, 1);
            t.need = clamp(Json.num(tm, "need", 0), 0, 100);
            t.tolerance = clamp(Json.num(tm, "tolerance", 10), 0, 100);
            t.holdMs = clamp(Json.num(tm, "holdMs", 0), 0, 600_000);
            t.fire = clamp(Json.num(tm, "fire", 0), 0, 1);
            t.cooldownMs = clamp(Json.num(tm, "cooldownMs", 500), 0, 3_600_000);
            t.together = Json.bool(tm, "together");
            for (Object wo : Json.list(tm, "watches")) {
                if (!(wo instanceof Map)) continue;
                Map<String, Object> wm = (Map<String, Object>) wo;
                Watch w = new Watch();
                w.x = (int) Json.num(wm, "x", 0);
                w.y = (int) Json.num(wm, "y", 0);
                w.color = parseColor(Json.str(wm, "color", "#FFFFFFFF"));
                w.picked = Json.bool(wm, "picked");
                w.invert = Json.bool(wm, "invert");
                t.watches.add(w);
            }
            for (Object a : Json.list(tm, "actions")) if (a instanceof Map) t.actions.add(target((Map<String, Object>) a));
            s.triggers.add(t);
        }
        return s;
    }

    private static Target target(Map<String, Object> m) {
        Target t = new Target();
        t.x = (int) Json.num(m, "x", 0);
        t.y = (int) Json.num(m, "y", 0);
        t.x2 = (int) Json.num(m, "x2", t.x);
        t.y2 = (int) Json.num(m, "y2", t.y);
        t.type = clamp(Json.num(m, "type", 0), 0, 3);
        t.holdMs = clamp(Json.num(m, "holdMs", 600), 1, 60_000);
        t.delayMs = clamp(Json.num(m, "delayMs", 100), 0, 3_600_000);
        t.repeat = clamp(Json.num(m, "repeat", 1), 1, 100_000);
        return t;
    }

    static int clamp(long v, int lo, int hi) {
        return (int) Math.max(lo, Math.min(hi, v));
    }

    static int parseColor(String s) {
        try {
            String h = s.startsWith("#") ? s.substring(1) : s;
            if (h.length() == 6) return 0xFF000000 | Integer.parseInt(h, 16);
            if (h.length() == 8) return (int) Long.parseLong(h, 16);
        } catch (NumberFormatException ignored) {
        }
        return 0xFFFFFFFF;
    }

    static String hex(int c) {
        return String.format("#%06X", c & 0xFFFFFF);
    }
}
