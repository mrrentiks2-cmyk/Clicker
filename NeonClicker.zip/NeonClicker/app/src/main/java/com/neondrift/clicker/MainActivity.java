package com.neondrift.clicker;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.function.Consumer;

/** Главный экран: включение службы, список сценариев, импорт и экспорт, настройки. */
public class MainActivity extends Activity {
    private static final int REQ_IMPORT = 1, REQ_EXPORT = 2;

    private Ui ui;
    private Prefs prefs;
    private LinearLayout box;
    private SidePanel panel;
    private Model.Scenario exporting;
    private int accentAtCreate;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        Theme.load(this);
        ui = new Ui(this);
        prefs = new Prefs(this);
        accentAtCreate = prefs.accent();
        getWindow().setStatusBarColor(Theme.BG);
        getWindow().setNavigationBarColor(Theme.BG);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Theme.BG);
        LinearLayout page = ui.col();
        LinearLayout top = ui.row();
        top.setPadding(ui.dp(20), ui.dp(14), ui.dp(8), ui.dp(6));
        ImageView logo = new ImageView(this);
        logo.setImageDrawable(new Glyph("tap", Theme.ACCENT));
        top.addView(logo, Ui.lp(ui.dp(30), ui.dp(30)));
        top.addView(ui.text("Neon Clicker", 22, Theme.TEXT, true), Ui.margins(0, Ui.WRAP, ui.dp(12), 0, 0, 0));
        ((LinearLayout.LayoutParams) top.getChildAt(1).getLayoutParams()).weight = 1f;
        top.addView(ui.iconButton("import", Theme.TEXT, 44, 11, v -> importScenario()));
        top.addView(ui.iconButton("settings", Theme.TEXT, 44, 11, v -> settings()));
        page.addView(top);
        ScrollView sc = new ScrollView(this);
        sc.setVerticalScrollBarEnabled(false);
        box = ui.col();
        box.setPadding(ui.dp(16), ui.dp(4), ui.dp(16), ui.dp(110));
        sc.addView(box, new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
        page.addView(sc, Ui.lp(Ui.MATCH, 0, 1f));
        root.addView(page, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));

        LinearLayout fab = ui.row();
        fab.setGravity(Gravity.CENTER);
        fab.setPadding(ui.dp(18), 0, ui.dp(22), 0);
        ImageView plus = new ImageView(this);
        plus.setImageDrawable(new Glyph("plus", Theme.BG));
        fab.addView(plus, Ui.lp(ui.dp(24), ui.dp(24)));
        fab.addView(ui.text("Новый сценарий", 15, Theme.BG, true), Ui.margins(Ui.WRAP, Ui.WRAP, ui.dp(8), 0, 0, 0));
        fab.setBackground(Ui.ripple(Ui.round(Theme.ACCENT, ui.dp(20)), Ui.round(0xFFFFFFFF, ui.dp(20))));
        fab.setElevation(ui.dp(10));
        fab.setOnClickListener(v -> create());
        FrameLayout.LayoutParams fp = new FrameLayout.LayoutParams(Ui.WRAP, ui.dp(56), Gravity.BOTTOM | Gravity.END);
        fp.setMargins(0, 0, ui.dp(16), ui.dp(20));
        root.addView(fab, fp);

        panel = new SidePanel(this, ui);
        root.addView(panel, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        setContentView(root);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (prefs.accent() != accentAtCreate) {
            recreate();
            return;
        }
        build();
    }

    // ================================================================== экран

    private void build() {
        box.removeAllViews();
        boolean on = ClickService.enabled(this);
        if (!on || ClickService.instance == null) setupCard(on);
        else {
            TextView ok = ui.text("✓ Служба включена — можно запускать", 13, 0xFF3DFF8C, true);
            ok.setPadding(ui.dp(4), ui.dp(6), 0, ui.dp(6));
            box.addView(ok);
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            TextView n = ui.text("Разрешите уведомления — в них кнопки «Пауза» и «Закрыть» ›", 13, Theme.ACCENT2, false);
            n.setPadding(ui.dp(4), ui.dp(4), 0, ui.dp(8));
            n.setOnClickListener(v -> requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 5));
            box.addView(n);
        }
        List<Model.Scenario> all = Store.all(this);
        box.addView(ui.label("СЦЕНАРИИ"), Ui.margins(Ui.WRAP, Ui.WRAP, ui.dp(4), ui.dp(16), 0, ui.dp(10)));
        if (all.isEmpty()) {
            guide();
            return;
        }
        for (Model.Scenario s : all) box.addView(card(s), Ui.margins(Ui.MATCH, Ui.WRAP, 0, 0, 0, ui.dp(10)));
        TextView tip = ui.text("Во время работы: кнопка громкости вниз — пауза. Кнопки «Пауза» и «Закрыть» есть и в шторке уведомлений.", 12, Theme.MUTED, false);
        tip.setLineSpacing(0, 1.25f);
        tip.setPadding(ui.dp(4), ui.dp(8), ui.dp(4), 0);
        box.addView(tip);
    }

    /** Подсказка, как включить службу (с учётом «ограниченных настроек» Android 13+). */
    private void setupCard(boolean enabledButDead) {
        LinearLayout c = ui.col();
        c.setPadding(ui.dp(18), ui.dp(16), ui.dp(18), ui.dp(16));
        c.setBackground(Ui.stroke(Theme.SURFACE, Theme.alpha(Theme.ACCENT, 160), ui.dp(1.5f), ui.dp(20)));
        c.addView(ui.text(enabledButDead ? "Служба включена, но не отвечает" : "Включите Neon Clicker в спецвозможностях", 16.5f, Theme.TEXT, true));
        String text = enabledButDead
                ? "Выключите и снова включите «Neon Clicker» в настройках спецвозможностей."
                : "Нажимать на экран за вас Android разрешает только службам спецвозможностей. Кликер не читает текст на экране и ничего никуда не отправляет.";
        TextView t = ui.text(text, 13, Theme.MUTED, false);
        t.setLineSpacing(0, 1.3f);
        c.addView(t, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(8), 0, ui.dp(4)));
        Form f = new Form(this, ui, c);
        f.button("1. Открыть спецвозможности", true, () -> {
            try {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                toast("Найдите «Neon Clicker» (иногда в «Установленные приложения») и включите");
            } catch (Exception e) {
                toast("Откройте Настройки → Спецвозможности вручную");
            }
        });
        if (Build.VERSION.SDK_INT >= 33) {
            f.note("Если переключатель серый и пишет «Ограниченная настройка» — это защита Android для приложений не из Play Маркета:");
            f.button("2. Сведения о приложении → ⋮ → «Разрешить ограниченные настройки»", false, () -> {
                try {
                    startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName())));
                } catch (Exception e) {
                    toast("Откройте Настройки → Приложения → Neon Clicker");
                }
            });
            f.note("Затем вернитесь к шагу 1. На некоторых телефонах пункт ⋮ появляется только после первой попытки включить службу.");
        }
        box.addView(c, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(6), 0, ui.dp(4)));
    }

    private void guide() {
        LinearLayout c = ui.col();
        c.setPadding(ui.dp(18), ui.dp(16), ui.dp(18), ui.dp(18));
        c.setBackground(Ui.round(Theme.SURFACE, ui.dp(20)));
        c.addView(ui.text("Как это работает", 16, Theme.TEXT, true));
        String[] steps = {
                "Нажмите «Новый сценарий» — поверх экрана появится панель и точки.",
                "Перетащите точки туда, куда нажимать. Нажатие на точку открывает её настройки: тип, паузу, повторы.",
                "Клики по цвету: поставьте кольца на места, где появляется цвет, и точку нажатия. Когда цвета совпадут — кликер нажмёт сам.",
                "Откройте нужное приложение и нажмите ▶ на панели."};
        for (int i = 0; i < steps.length; i++) {
            LinearLayout row = ui.row();
            row.setGravity(Gravity.TOP);
            TextView n = ui.text(String.valueOf(i + 1), 13, Theme.BG, true);
            n.setGravity(Gravity.CENTER);
            n.setBackground(Ui.oval(Theme.ACCENT));
            row.addView(n, Ui.lp(ui.dp(24), ui.dp(24)));
            TextView t = ui.text(steps[i], 13.5f, Theme.MUTED, false);
            t.setLineSpacing(0, 1.3f);
            row.addView(t, Ui.margins(0, Ui.WRAP, ui.dp(12), 0, 0, 0));
            ((LinearLayout.LayoutParams) t.getLayoutParams()).weight = 1f;
            c.addView(row, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(12), 0, 0));
        }
        box.addView(c);
    }

    private View card(Model.Scenario s) {
        LinearLayout c = ui.row();
        c.setPadding(ui.dp(16), ui.dp(14), ui.dp(8), ui.dp(14));
        c.setBackground(Ui.ripple(Ui.stroke(Theme.SURFACE, Theme.LINE, ui.dp(1), ui.dp(18)), Ui.round(0xFFFFFFFF, ui.dp(18))));
        LinearLayout tx = ui.col();
        tx.addView(ui.oneLine(s.name, 16, Theme.TEXT, true));
        StringBuilder sb = new StringBuilder();
        if (!s.targets.isEmpty()) sb.append(Logic.plural(s.targets.size(), "точка", "точки", "точек")).append(" по кругу");
        if (!s.triggers.isEmpty()) {
            if (sb.length() > 0) sb.append(" · ");
            sb.append(Logic.plural(s.triggers.size(), "триггер", "триггера", "триггеров")).append(" по цвету");
        }
        if (sb.length() == 0) sb.append("Пока пусто");
        if (s.cycles > 0 && !s.targets.isEmpty()) sb.append(" · ").append(s.cycles).append(" кр.");
        TextView sub = ui.text(sb.toString(), 12.5f, Theme.MUTED, false);
        tx.addView(sub, Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(4), 0, 0));
        c.addView(tx, Ui.lp(0, Ui.WRAP, 1f));
        ImageView play = ui.iconButton("play", Theme.BG, 46, 12, v -> run(s));
        play.setBackground(Ui.ripple(Ui.oval(Theme.ACCENT), Ui.oval(0xFFFFFFFF)));
        play.setContentDescription("Запустить");
        c.addView(play);
        c.addView(ui.iconButton("more", Theme.MUTED, 42, 10, v -> menu(s)));
        c.setOnClickListener(v -> run(s));
        c.setOnLongClickListener(v -> {
            menu(s);
            return true;
        });
        return c;
    }

    // ================================================================== действия

    private void run(Model.Scenario s) {
        if (!ClickService.enabled(this) || ClickService.instance == null) {
            toast("Сначала включите службу в спецвозможностях");
            return;
        }
        if (ClickService.open(this, s.id)) {
            toast("Откройте нужное приложение и нажмите ▶ на панели");
            moveTaskToBack(true);
        }
    }

    private void create() {
        Model.Scenario s = new Model.Scenario();
        s.name = Store.freeName(this, "Сценарий");
        s.created = s.edited = System.currentTimeMillis();
        Store.save(this, s);
        run(s);
        build();
    }

    private void menu(Model.Scenario s) {
        LinearLayout b = panel.open(s.name);
        panel.option(b, "Запустить", null, false, () -> {
            panel.close();
            run(s);
        });
        panel.option(b, "Переименовать", null, false, () -> {
            panel.close();
            prompt("Название сценария", s.name, name -> {
                s.name = name;
                s.edited = System.currentTimeMillis();
                Store.save(this, s);
                build();
            });
        });
        panel.option(b, "Создать копию", null, false, () -> {
            panel.close();
            Model.Scenario c = s.copy();
            c.name = Store.freeName(this, s.name + " копия");
            c.created = c.edited = System.currentTimeMillis();
            c.lastRun = 0;
            Store.save(this, c);
            build();
        });
        panel.option(b, "Сохранить в файл", "Чтобы перенести на другой телефон", false, () -> {
            panel.close();
            exporting = s;
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json")
                    .putExtra(Intent.EXTRA_TITLE, s.name.replaceAll("[\\\\/:*?\"<>|]", " ").trim() + ".json");
            try {
                startActivityForResult(i, REQ_EXPORT);
            } catch (Exception e) {
                toast("Нет приложения для выбора папки");
            }
        });
        panel.option(b, "Поделиться", "Текстом — его можно вставить через импорт", false, () -> {
            panel.close();
            Intent i = new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, Model.toJson(s));
            startActivity(Intent.createChooser(i, "Поделиться сценарием"));
        });
        panel.option(b, "Удалить", null, false, () -> {
            panel.close();
            dialog().setTitle("Удалить «" + s.name + "»?").setPositiveButton("Удалить", (d, w) -> {
                Store.delete(this, s.id);
                build();
            }).setNegativeButton("Отмена", null).show();
        });
    }

    private void importScenario() {
        LinearLayout b = panel.open("Импорт сценария");
        panel.option(b, "Из файла .json", null, false, () -> {
            panel.close();
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*");
            try {
                startActivityForResult(i, REQ_IMPORT);
            } catch (Exception e) {
                toast("Нет приложения для выбора файла");
            }
        });
        panel.option(b, "Из буфера обмена", "Если сценарий прислали текстом", false, () -> {
            panel.close();
            android.content.ClipboardManager cm = getSystemService(android.content.ClipboardManager.class);
            CharSequence t = cm != null && cm.getPrimaryClip() != null && cm.getPrimaryClip().getItemCount() > 0
                    ? cm.getPrimaryClip().getItemAt(0).coerceToText(this) : null;
            if (t == null) toast("Буфер обмена пуст");
            else addImported(t.toString());
        });
    }

    private void addImported(String json) {
        try {
            Model.Scenario s = Model.fromJson(json.trim());
            s.id = java.util.UUID.randomUUID().toString();
            s.name = Store.freeName(this, s.name);
            s.edited = System.currentTimeMillis();
            Store.save(this, s);
            toast("Добавлен «" + s.name + "»");
            build();
        } catch (Exception e) {
            toast("Это не сценарий Neon Clicker");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        if (req == REQ_IMPORT) {
            try (InputStream in = getContentResolver().openInputStream(data.getData())) {
                addImported(Store.read(in));
            } catch (Exception e) {
                toast("Не удалось прочитать файл");
            }
        } else if (req == REQ_EXPORT && exporting != null) {
            try (OutputStream out = getContentResolver().openOutputStream(data.getData(), "wt")) {
                out.write(Model.toJson(exporting).getBytes(StandardCharsets.UTF_8));
                toast("Сохранено");
            } catch (Exception e) {
                toast("Не удалось сохранить");
            }
            exporting = null;
        }
    }

    private void settings() {
        LinearLayout b = panel.open("Настройки");
        panel.section(b, "ЦВЕТ");
        LinearLayout row = panel.chipRow(b);
        for (int i = 0; i < Theme.ACCENT_NAMES.length; i++) {
            int k = i;
            panel.chip(row, Theme.ACCENT_NAMES[i], prefs.accent() == i, () -> {
                prefs.put("accent", k);
                panel.close();
                recreate();
            });
        }
        Form f = new Form(this, ui, b);
        f.section("УПРАВЛЕНИЕ");
        f.toggle("Громкость вниз — пауза", "Аварийная остановка кликера кнопкой громкости", prefs.volumeStop(), on -> prefs.put("volumeStop", on));
        f.counter("Размер меток на экране", prefs.markerSize(), 60, 160, v -> v + "%", v -> prefs.put("markerSize", v));
        f.section("О ПРИЛОЖЕНИИ");
        f.note("Neon Clicker нажимает за вас через службу спецвозможностей. Для кликов по цвету он смотрит на экран — "
                + "только в точках, которые вы отметили, и только пока открыта панель. Ничего не сохраняет и не отправляет.");
        f.button("Настройки спецвозможностей", false, () -> {
            try {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            } catch (Exception ignored) {
            }
        });
    }

    // ================================================================== мелочи

    private AlertDialog.Builder dialog() {
        return new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert);
    }

    private void prompt(String title, String value, Consumer<String> done) {
        EditText e = new EditText(this);
        e.setText(value);
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        e.setTextColor(Theme.TEXT);
        e.setSelection(e.getText().length());
        FrameLayout f = new FrameLayout(this);
        f.setPadding(ui.dp(22), ui.dp(8), ui.dp(22), 0);
        f.addView(e);
        AlertDialog d = dialog().setTitle(title).setView(f).setPositiveButton("Готово", (x, w) -> {
            String s = e.getText().toString().trim();
            if (!s.isEmpty()) done.accept(s);
        }).setNegativeButton("Отмена", null).create();
        d.setOnShowListener(x -> {
            e.requestFocus();
            getSystemService(InputMethodManager.class).showSoftInput(e, InputMethodManager.SHOW_IMPLICIT);
        });
        d.show();
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    @Override
    public void onBackPressed() {
        if (panel.isOpen()) panel.close();
        else super.onBackPressed();
    }
}
