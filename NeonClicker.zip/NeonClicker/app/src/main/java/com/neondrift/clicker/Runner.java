package com.neondrift.clicker;

import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Исполнитель сценария. Всё работает в главном потоке:
 * клики по кругу идут очередью, триггеры по цвету проверяются по таймеру и встают в начало очереди.
 * Жест отправляется только после завершения предыдущего — иначе система отменила бы прошлый.
 */
final class Runner {
    interface Host {
        /** Отправить жест; done вызвать по завершении (или отмене). false — жест не принят. */
        boolean gesture(List<Logic.Stroke> strokes, Runnable done);
        /** Текущие цвета в точках триггера, null — экран пока не виден. */
        int[] colors(Model.Trigger t);
        int screenW();
        int screenH();
        int maxStrokes();
        void onChanged();
        void onFinished(String why);
    }

    static final int IDLE = 0, RUNNING = 1, PAUSED = 2;

    private static final class Step {
        final List<Logic.Stroke> strokes;
        final long delayAfter;

        Step(List<Logic.Stroke> strokes, long delayAfter) {
            this.strokes = strokes;
            this.delayAfter = delayAfter;
        }
    }

    private static final class Job {
        final List<Step> steps = new ArrayList<>();
        int trigger = -1;      // номер триггера или −1 для кликов по кругу
        long sequenceDelay;    // для кругов: пауза перед следующей точкой
    }

    private final Handler h = new Handler(Looper.getMainLooper());
    private final Host host;
    private final Random rnd = new Random();
    Model.Scenario s;
    int state = IDLE;
    private Logic.Sequencer seq;
    Logic.TriggerState[] states = new Logic.TriggerState[0];
    private boolean[] pendingTrigger = new boolean[0];
    boolean[] condNow = new boolean[0];
    private final ArrayDeque<Job> queue = new ArrayDeque<>();
    private boolean busy, seqWaiting;
    private long activeMs, resumedAt;
    long gestures, fires;
    private long gestureToken;

    Runner(Host host) {
        this.host = host;
    }

    // ================================================================== управление

    void start(Model.Scenario sc) {
        stop();
        s = sc;
        seq = new Logic.Sequencer(s.targets, s.cycles);
        states = new Logic.TriggerState[s.triggers.size()];
        for (int i = 0; i < states.length; i++) states[i] = new Logic.TriggerState();
        pendingTrigger = new boolean[states.length];
        condNow = new boolean[states.length];
        gestures = fires = 0;
        activeMs = 0;
        state = RUNNING;
        resumedAt = SystemClock.uptimeMillis();
        kick();
        host.onChanged();
    }

    void pause() {
        if (state != RUNNING) return;
        activeMs += SystemClock.uptimeMillis() - resumedAt;
        state = PAUSED;
        h.removeCallbacksAndMessages(null);
        queue.clear();
        busy = false;
        seqWaiting = false;
        for (int i = 0; i < pendingTrigger.length; i++) pendingTrigger[i] = false;
        gestureToken++;
        host.onChanged();
    }

    void resume() {
        if (state != PAUSED) return;
        state = RUNNING;
        resumedAt = SystemClock.uptimeMillis();
        for (Logic.TriggerState st : states) st.reset();
        kick();
        host.onChanged();
    }

    void stop() {
        h.removeCallbacksAndMessages(null);
        queue.clear();
        busy = false;
        seqWaiting = false;
        gestureToken++;
        if (state == RUNNING) activeMs += SystemClock.uptimeMillis() - resumedAt;
        state = IDLE;
    }

    /** Структура сценария поменялась во время паузы. */
    void rebuild() {
        if (s == null) return;
        int n = s.triggers.size();
        if (states.length != n) {
            states = new Logic.TriggerState[n];
            for (int i = 0; i < n; i++) states[i] = new Logic.TriggerState();
            pendingTrigger = new boolean[n];
            condNow = new boolean[n];
        }
        if (seq == null || seq.targets != s.targets) seq = new Logic.Sequencer(s.targets, s.cycles);
    }

    long elapsed() {
        return activeMs + (state == RUNNING ? SystemClock.uptimeMillis() - resumedAt : 0);
    }

    long cycle() {
        return seq == null ? 0 : seq.cycle;
    }

    private void kick() {
        if (!s.targets.isEmpty() && !seq.finished()) h.post(seqStep);
        if (!s.triggers.isEmpty()) h.post(tick);
        h.post(watchdog);
    }

    // ================================================================== клики по кругу

    private final Runnable seqStep = new Runnable() {
        @Override
        public void run() {
            if (state != RUNNING || seqWaiting) return;
            Model.Target t = seq.next();
            if (t == null) {
                if (s.triggers.isEmpty()) finish("Все круги выполнены");
                return;
            }
            Job j = new Job();
            j.steps.add(new Step(Logic.plan(t, s, rnd, host.screenW(), host.screenH()), 0));
            j.sequenceDelay = Logic.jitter(t.delayMs, s.jitterPct, rnd);
            seqWaiting = true;
            queue.addLast(j);
            pump();
        }
    };

    // ================================================================== триггеры

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (state != RUNNING) return;
            long now = SystemClock.uptimeMillis();
            for (int i = 0; i < s.triggers.size() && i < states.length; i++) {
                Model.Trigger t = s.triggers.get(i);
                if (!t.enabled || t.actions.isEmpty()) continue;
                int[] c = host.colors(t);
                if (c == null) continue;
                boolean cond = Logic.condition(t, c);
                condNow[i] = cond;
                if (states[i].update(t, cond, now) && !pendingTrigger[i]) enqueueTrigger(i, t);
            }
            h.postDelayed(this, Math.max(16, 1000 / Math.max(1, s.checkHz)));
        }
    };

    private void enqueueTrigger(int i, Model.Trigger t) {
        Job j = new Job();
        j.trigger = i;
        if (t.together && t.actions.size() > 1) {
            j.steps.add(new Step(Logic.together(t.actions, s, rnd, host.screenW(), host.screenH(), host.maxStrokes()), 0));
        } else {
            for (Model.Target a : t.actions) {
                for (int r = 0; r < Math.max(1, a.repeat); r++) {
                    j.steps.add(new Step(Logic.plan(a, s, rnd, host.screenW(), host.screenH()), Logic.jitter(a.delayMs, s.jitterPct, rnd)));
                }
            }
        }
        pendingTrigger[i] = true;
        fires++;
        queue.addFirst(j); // триггеры важнее кругов
        pump();
    }

    // ================================================================== очередь жестов

    private void pump() {
        if (busy || state != RUNNING || queue.isEmpty()) return;
        Job j = queue.pollFirst();
        busy = true;
        runStep(j, 0);
    }

    private void runStep(Job j, int i) {
        if (state != RUNNING) return;
        if (i >= j.steps.size()) {
            busy = false;
            if (j.trigger >= 0 && j.trigger < pendingTrigger.length) pendingTrigger[j.trigger] = false;
            if (j.trigger < 0) {
                seqWaiting = false;
                h.postDelayed(seqStep, j.sequenceDelay);
            }
            pump();
            return;
        }
        Step st = j.steps.get(i);
        long token = ++gestureToken;
        boolean[] done = {false};
        Runnable[] next = new Runnable[1];
        next[0] = () -> {
            if (done[0] || token != gestureToken) return;
            done[0] = true;
            h.removeCallbacks(next[0]);
            gestures++;
            if (st.delayAfter > 0) h.postDelayed(() -> runStep(j, i + 1), st.delayAfter);
            else runStep(j, i + 1);
        };
        // если система не ответила — не зависаем
        h.postDelayed(next[0], Logic.gestureLength(st.strokes) + 1500);
        if (!host.gesture(st.strokes, () -> h.post(next[0]))) {
            h.removeCallbacks(next[0]);
            h.postDelayed(next[0], 50);
        }
    }

    /** Ограничение по времени. */
    private final Runnable watchdog = new Runnable() {
        @Override
        public void run() {
            if (state != RUNNING) return;
            if (s.stopAfterMs > 0 && elapsed() >= s.stopAfterMs) {
                finish("Время вышло");
                return;
            }
            h.postDelayed(this, 250);
        }
    };

    private void finish(String why) {
        stop();
        host.onChanged();
        host.onFinished(why);
    }
}
