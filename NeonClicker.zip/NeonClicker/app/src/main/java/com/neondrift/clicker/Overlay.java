package com.neondrift.clicker;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Окна поверх экрана: слой с точками, плавающая панель и карточка настроек выбранной точки.
 * Все окна — TYPE_ACCESSIBILITY_OVERLAY: отдельное разрешение «поверх других окон» не нужно.
 */
final class Overlay implements Board.Listener {
    private static final ExecutorService SAVE = Executors.newSingleThreadExecutor();

    final ClickService svc;
    final Model.Scenario s;
    private final Context ctx;
    private final WindowManager wm;
    private final Ui ui;
    private final Handler h = new Handler(Looper.getMainLooper());

    private Board board;
    private WindowManager.LayoutParams boardLp, panelLp, cardLp;
    private LinearLayout panel;
    private TextView stats;
    private ImageView playBtn, eyeBtn;
    private FrameLayout card;
    private LinearLayout cardBox;
    private boolean cardShown, markersHidden, captureWasReady;
    private Object cardFor;          // что сейчас в карточке
    private TextView liveText;       // живая строка «совпало 2 из 3» в карточке триггера
    private Model.Trigger liveTrigger;
    private Model.Watch pickAfterCapture;

    Overlay(ClickService svc, Model.Scenario s) {
        this.svc = svc;
        this.s = s;
        this.ctx = new ContextThemeWrapper(svc, android.R.style.Theme_DeviceDefault);
        this.wm = svc.getSystemService(WindowManager.class);
        this.ui = new Ui(ctx);
    }

    private WindowManager.LayoutParams params(int w, int h, int extraFlags) {
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS | extraFlags, PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.START;
        if (Build.VERSION.SDK_INT >= 30) p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
        else if (Build.VERSION.SDK_INT >= 28) p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        return p;
    }

    // ================================================================== показ и закрытие

    void show() {
        int[] size = svc.realSize();
        if (s.screenW > 0 && (s.screenW != size[0] || s.screenH != size[1])) {
            s.scaleTo(size[0], size[1]);
            svc.toast("Точки пересчитаны под этот экран");
            save();
        } else if (s.screenW <= 0) {
            s.screenW = size[0];
            s.screenH = size[1];
        }
        board = new Board(ctx, ui, this);
        board.s = s;
        board.scale = new Prefs(svc).markerSize() / 100f;
        boardLp = params(size[0], size[1], 0);
        wm.addView(board, boardLp);
        buildPanel();
        buildCard();
        if (!s.triggers.isEmpty()) svc.requestCapture();
        h.post(preview);
        refresh();
        if (board.empty()) h.postDelayed(this::addMenu, 300);
    }

    void dismiss() {
        h.removeCallbacksAndMessages(null);
        save();
        for (View v : new View[]{board, panel, card}) {
            if (v == null) continue;
            try {
                wm.removeView(v);
            } catch (Exception ignored) {
            }
        }
        board = null;
    }

    void onRotate() {
        if (board == null) return;
        int[] size = svc.realSize();
        if (size[0] == boardLp.width && size[1] == boardLp.height) return;
        s.scaleTo(size[0], size[1]);
        boardLp.width = size[0];
        boardLp.height = size[1];
        wm.updateViewLayout(board, boardLp);
        clampPanel();
        save();
        refresh();
    }

    // ================================================================== панель

    @SuppressLint("ClickableViewAccessibility")
    private void buildPanel() {
        panel = ui.col();
        panel.setPadding(ui.dp(6), ui.dp(5), ui.dp(6), ui.dp(5));
        panel.setBackground(Ui.stroke(0xF0120F1C, Theme.alpha(Theme.ACCENT, 150), ui.dp(1.5f), ui.dp(24)));
        panel.setElevation(ui.dp(8));
        LinearLayout row = ui.row();
        ImageView handle = new ImageView(ctx);
        handle.setImageDrawable(new Glyph("drag", Theme.MUTED));
        int p = ui.dp(9);
        handle.setPadding(p, p, p, p);
        handle.setContentDescription("Перетащить панель");
        row.addView(handle, Ui.lp(ui.dp(36), ui.dp(44)));
        playBtn = ui.iconButton("play", Theme.BG, 44, 11, v -> togglePlay());
        playBtn.setBackground(Ui.ripple(Ui.oval(Theme.ACCENT), Ui.oval(0xFFFFFFFF)));
        row.addView(playBtn);
        row.addView(ui.iconButton("plus", Theme.TEXT, 44, 11, v -> addMenu()));
        eyeBtn = ui.iconButton("eye", Theme.TEXT, 44, 11, v -> toggleMarkers());
        row.addView(eyeBtn);
        row.addView(ui.iconButton("settings", Theme.TEXT, 44, 11, v -> scenarioCard()));
        row.addView(ui.iconButton("close", Theme.TEXT, 44, 11, v -> svc.closeOverlay()));
        panel.addView(row);
        stats = ui.text("", 11.5f, Theme.MUTED, false);
        stats.setPadding(ui.dp(10), 0, ui.dp(10), ui.dp(4));
        stats.setVisibility(View.GONE);
        panel.addView(stats);

        Prefs pr = new Prefs(svc);
        panelLp = params(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, 0);
        int[] size = svc.realSize();
        panelLp.x = pr.panelX() >= 0 ? pr.panelX() : ui.dp(12);
        panelLp.y = pr.panelY() >= 0 ? pr.panelY() : size[1] / 3;
        wm.addView(panel, panelLp);
        clampPanel();

        float[] start = new float[4];
        handle.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    start[0] = e.getRawX();
                    start[1] = e.getRawY();
                    start[2] = panelLp.x;
                    start[3] = panelLp.y;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    panelLp.x = Math.round(start[2] + e.getRawX() - start[0]);
                    panelLp.y = Math.round(start[3] + e.getRawY() - start[1]);
                    clampPanel();
                    return true;
                case MotionEvent.ACTION_UP:
                    Prefs pp = new Prefs(svc);
                    pp.put("panelX", panelLp.x);
                    pp.put("panelY", panelLp.y);
                    return true;
                default:
                    return true;
            }
        });
    }

    private void clampPanel() {
        int[] size = svc.realSize();
        panel.measure(View.MeasureSpec.makeMeasureSpec(size[0], View.MeasureSpec.AT_MOST), View.MeasureSpec.makeMeasureSpec(size[1], View.MeasureSpec.AT_MOST));
        panelLp.x = Math.max(0, Math.min(size[0] - panel.getMeasuredWidth(), panelLp.x));
        panelLp.y = Math.max(0, Math.min(size[1] - panel.getMeasuredHeight(), panelLp.y));
        try {
            wm.updateViewLayout(panel, panelLp);
        } catch (Exception ignored) {
        }
    }

    /** Обновить вид после смены состояния. */
    void refresh() {
        if (board == null) return;
        Runner r = svc.runner;
        boolean run = r.state == Runner.RUNNING;
        board.running = run;
        board.hidden = markersHidden;
        playBtn.setImageDrawable(new Glyph(run ? "pause" : "play", Theme.BG));
        playBtn.setContentDescription(run ? "Пауза" : "Старт");
        eyeBtn.setImageDrawable(new Glyph(markersHidden ? "eyeOff" : "eye", Theme.TEXT));
        boolean touch = !run && !markersHidden;
        int flags = boardLp.flags;
        if (touch) boardLp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        else boardLp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        if (flags != boardLp.flags) wm.updateViewLayout(board, boardLp);
        if (run && cardShown) hideCard();
        stats.setVisibility(r.state == Runner.IDLE ? View.GONE : View.VISIBLE);
        if (run) board.cond = r.condNow;
        updateStats();
        board.invalidate();
    }

    private void updateStats() {
        Runner r = svc.runner;
        if (r.state == Runner.IDLE) return;
        StringBuilder sb = new StringBuilder(r.state == Runner.PAUSED ? "⏸ " : "● ");
        sb.append(Logic.clock(r.elapsed())).append(" · ").append(Logic.plural(r.gestures, "клик", "клика", "кликов"));
        if (!s.triggers.isEmpty()) sb.append(" · по цвету ").append(r.fires);
        if (!s.targets.isEmpty() && s.cycles > 0) sb.append(" · круг ").append(Math.min(s.cycles, r.cycle() + 1)).append('/').append(s.cycles);
        stats.setText(sb);
    }

    void togglePlay() {
        Runner r = svc.runner;
        if (r.state == Runner.RUNNING) {
            r.pause();
            svc.clearAutoPause();
        } else if (r.state == Runner.PAUSED) {
            r.rebuild();
            svc.markRunPackage();
            r.resume();
        } else {
            if (s.targets.isEmpty() && s.triggers.isEmpty()) {
                svc.toast("Сначала добавьте точку");
                addMenu();
                return;
            }
            for (Model.Trigger t : s.triggers) {
                if (t.enabled && t.actions.isEmpty()) {
                    svc.toast("У триггера нет точки нажатия");
                    return;
                }
            }
            if (!s.triggers.isEmpty() && !svc.captureReady()) svc.requestCapture();
            s.lastRun = System.currentTimeMillis();
            save();
            hideCard();
            svc.markRunPackage();
            r.start(s);
        }
        refresh();
    }

    void pauseBy(String why) {
        if (svc.runner.state != Runner.RUNNING) return;
        svc.runner.pause();
        svc.toast(why);
        refresh();
    }

    void resumeBy(String why) {
        if (svc.runner.state != Runner.PAUSED) return;
        svc.runner.resume();
        svc.toast(why);
        refresh();
    }

    void onFinished(String why) {
        svc.toast(why + ": " + Logic.plural(svc.runner.gestures, "клик", "клика", "кликов"));
        refresh();
    }

    private void toggleMarkers() {
        markersHidden = !markersHidden;
        if (markersHidden) hideCard();
        svc.toast(markersHidden ? "Точки скрыты — экран можно трогать" : "Точки видны");
        refresh();
    }

    // ================================================================== живые цвета

    /** Раз в ~150 мс: цвета под точками проверки и выполнено ли условие; лупа и карточка триггера. */
    private final Runnable preview = new Runnable() {
        @Override
        public void run() {
            if (board == null) return;
            int n = s.triggers.size();
            int[][] live = new int[n][];
            boolean[] cond = new boolean[n];
            for (int i = 0; i < n; i++) {
                Model.Trigger t = s.triggers.get(i);
                live[i] = svc.colors(t);
                cond[i] = live[i] != null && Logic.condition(t, live[i]);
            }
            board.live = live;
            if (svc.runner.state != Runner.RUNNING) board.cond = cond;
            board.invalidate();
            if (liveText != null && liveTrigger != null) {
                int i = s.triggers.indexOf(liveTrigger);
                if (i >= 0 && live[i] != null) {
                    liveText.setText((cond[i] ? "✓ Сейчас выполнено: " : "Сейчас: ") + Logic.progress(liveTrigger, live[i]));
                    liveText.setTextColor(cond[i] ? 0xFF3DFF8C : Theme.MUTED);
                } else {
                    liveText.setText(s.capture == 1 ? "Ждём снимок экрана…" : "Экран пока не виден — разрешите запись экрана");
                }
            }
            updateStats();
            h.postDelayed(this, svc.runner.state == Runner.RUNNING ? 250 : 150);
        }
    };

    void onCaptureChanged(boolean ok) {
        if (ok == captureWasReady) return;
        captureWasReady = ok;
        if (ok && pickAfterCapture != null) {
            Model.Watch w = pickAfterCapture;
            pickAfterCapture = null;
            h.postDelayed(() -> pick(w), 300);
        }
    }

    @Override
    public int[] patch(int x, int y, int r) {
        ColorSource src = svc.source();
        return src != null && src.ready() ? src.patch(x, y, r) : null;
    }

    /** Взять цвет под точкой проверки. */
    private void pick(Model.Watch w) {
        ColorSource src = svc.source();
        if (src == null || !src.ready()) {
            pickAfterCapture = w;
            svc.requestCapture();
            svc.toast("Разрешите запись экрана — цвет возьмётся сам");
            return;
        }
        int c = src.color(w.x, w.y);
        if (c == 0) return;
        w.color = c;
        w.picked = true;
        save();
        if (cardFor == w) watchCard(w);
        board.invalidate();
    }

    // ================================================================== Board.Listener

    @Override
    public void onSelect(Object item) {
        board.selected = item;
        board.invalidate();
        openCard(item);
    }

    @Override
    public void onMoved(Object item) {
        board.selected = item;
        if (item instanceof Model.Watch) {
            Model.Watch w = (Model.Watch) item;
            Model.Trigger t = owner(w);
            if (!w.picked && t != null && t.mode == Model.MATCH && svc.captureReady()) pick(w);
        }
        save();
        if (cardShown) openCard(item);
    }

    @Override
    public void onTapEmpty() {
        board.selected = null;
        board.invalidate();
        hideCard();
    }

    Model.Trigger owner(Object item) {
        for (Model.Trigger t : s.triggers) {
            if (t.watches.contains(item) || t.actions.contains(item)) return t;
        }
        return null;
    }

    // ================================================================== карточка

    private void buildCard() {
        card = new FrameLayout(ctx);
        card.setBackground(Ui.stroke(0xF5120F1C, Theme.LINE, ui.dp(1), ui.dp(22)));
        card.setElevation(ui.dp(10));
        ScrollView sc = new ScrollView(ctx) {
            @Override
            protected void onMeasure(int ws, int hs) {
                int max = Math.round(svc.realSize()[1] * 0.55f);
                super.onMeasure(ws, View.MeasureSpec.makeMeasureSpec(max, View.MeasureSpec.AT_MOST));
            }
        };
        sc.setVerticalScrollBarEnabled(false);
        cardBox = ui.col();
        cardBox.setPadding(ui.dp(16), ui.dp(10), ui.dp(16), ui.dp(14));
        sc.addView(cardBox, new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
        card.addView(sc, new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
        int w = Math.min(svc.realSize()[0] - ui.dp(24), ui.dp(380));
        cardLp = params(w, WindowManager.LayoutParams.WRAP_CONTENT, 0);
        card.setVisibility(View.GONE);
        wm.addView(card, cardLp);
    }

    /** Начать карточку: заголовок и кнопка закрытия. Возвращает форму для содержимого. */
    private Form startCard(String title, int color, Object item, int nearY) {
        cardBox.removeAllViews();
        liveText = null;
        liveTrigger = null;
        cardFor = item;
        LinearLayout head = ui.row();
        View dot = new View(ctx);
        dot.setBackground(Ui.oval(color));
        head.addView(dot, Ui.margins(ui.dp(10), ui.dp(10), 0, 0, ui.dp(10), 0));
        head.addView(ui.text(title, 16, Theme.TEXT, true), Ui.lp(0, Ui.WRAP, 1f));
        head.addView(ui.iconButton("close", Theme.MUTED, 38, 10, v -> {
            board.selected = null;
            board.invalidate();
            hideCard();
        }));
        cardBox.addView(head);
        // карточка — на другой половине экрана, чтобы не закрывать точку
        int[] size = svc.realSize();
        cardLp.width = Math.min(size[0] - ui.dp(24), ui.dp(380));
        cardLp.x = (size[0] - cardLp.width) / 2;
        boolean bottom = nearY < size[1] / 2;
        cardLp.gravity = Gravity.START | (bottom ? Gravity.BOTTOM : Gravity.TOP);
        cardLp.y = ui.dp(bottom ? 24 : 40);
        if (!cardShown) {
            card.setVisibility(View.VISIBLE);
            card.setAlpha(0f);
            card.animate().alpha(1f).setDuration(140).start();
            cardShown = true;
        }
        wm.updateViewLayout(card, cardLp);
        return new Form(ctx, ui, cardBox);
    }

    private void hideCard() {
        if (!cardShown) return;
        cardShown = false;
        cardFor = null;
        liveText = null;
        liveTrigger = null;
        card.setVisibility(View.GONE);
    }

    private void openCard(Object item) {
        if (item instanceof Model.Watch) watchCard((Model.Watch) item);
        else if (item instanceof Model.Target) targetCard((Model.Target) item);
        else if (item instanceof Model.Trigger) triggerCard((Model.Trigger) item);
    }

    // ---------------------------------------------------------------- точка нажатия

    private void targetCard(Model.Target t) {
        Model.Trigger tr = owner(t);
        int seqIndex = s.targets.indexOf(t);
        int ti = tr != null ? s.triggers.indexOf(tr) : -1;
        String title = tr != null ? "Нажатие триггера " + Board.letter(ti) : "Точка " + (seqIndex + 1) + " · по кругу";
        Form f = startCard(title, tr != null ? Board.triggerColor(ti) : Theme.ACCENT, t, t.y);
        f.chips("Что делать", Model.TYPE_NAMES, t.type, k -> {
            boolean wasSwipe = t.type == Model.SWIPE;
            t.type = k;
            if (k == Model.SWIPE && !wasSwipe) {
                int[] size = svc.realSize();
                t.x2 = Math.max(0, Math.min(size[0] - 1, t.x + ui.dp(140)));
                t.y2 = t.y;
                if (t.holdMs > 2000 || t.holdMs < 50) t.holdMs = 300;
            }
            if (k == Model.LONG && t.holdMs < 200) t.holdMs = 600;
            changed();
            targetCard(t);
        });
        if (t.type == Model.LONG) f.duration("Удерживать", t.holdMs, 50, 59_000, v -> { t.holdMs = (int) v; changed(); });
        if (t.type == Model.SWIPE) {
            f.duration("Длительность свайпа", t.holdMs, 10, 59_000, v -> { t.holdMs = (int) v; changed(); });
            f.note("Конец свайпа — маленький круг со стрелкой, его тоже можно тянуть.");
        }
        f.duration(tr != null && tr.actions.indexOf(t) == tr.actions.size() - 1 ? "Пауза после" : "Пауза до следующего", t.delayMs, 0, 3_600_000,
                v -> { t.delayMs = (int) v; changed(); });
        f.counter("Повторить подряд", t.repeat, 1, 100_000, v -> v == 1 ? "1 раз" : v + " раз", v -> { t.repeat = v; changed(); });
        if (tr == null) {
            f.buttons("◀ Раньше", false, () -> move(t, -1), "Позже ▶", false, () -> move(t, 1));
            f.buttons("Копия", false, () -> {
                Model.Target c = t.copy();
                c.x = Math.min(svc.realSize()[0] - 1, c.x + ui.dp(36));
                c.x2 = Math.min(svc.realSize()[0] - 1, c.x2 + ui.dp(36));
                s.targets.add(s.targets.indexOf(t) + 1, c);
                changed();
                onSelect(c);
            }, "Удалить", false, () -> {
                s.targets.remove(t);
                changed();
                onTapEmpty();
            });
        } else {
            f.buttons("Настройки " + Board.letter(ti), false, () -> triggerCard(tr), "Удалить", false, () -> {
                tr.actions.remove(t);
                changed();
                onTapEmpty();
            });
        }
    }

    private void move(Model.Target t, int dir) {
        int i = s.targets.indexOf(t), j = i + dir;
        if (i < 0 || j < 0 || j >= s.targets.size()) return;
        s.targets.remove(i);
        s.targets.add(j, t);
        changed();
        targetCard(t);
    }

    // ---------------------------------------------------------------- точка проверки

    private void watchCard(Model.Watch w) {
        Model.Trigger t = owner(w);
        if (t == null) return;
        int ti = s.triggers.indexOf(t);
        Form f = startCard("Точка проверки " + Board.letter(ti) + (t.watches.indexOf(w) + 1), Board.triggerColor(ti), w, w.y);
        LinearLayout row = ui.row();
        row.setPadding(0, ui.dp(8), 0, ui.dp(4));
        View sw = new View(ctx);
        sw.setBackground(Ui.stroke(w.picked ? w.color : 0xFF2B2442, Theme.TEXT, ui.dp(1.5f), ui.dp(10)));
        row.addView(sw, Ui.lp(ui.dp(44), ui.dp(44)));
        LinearLayout tx = ui.col();
        tx.addView(ui.text(t.mode == Model.SAME ? "Цвет не нужен" : w.picked ? "Образец " + Model.hex(w.color) : "Цвет ещё не взят", 14.5f, Theme.TEXT, true));
        String sub = t.mode == Model.SAME
                ? "В режиме «одинаковые» сравниваются точки между собой"
                : "Поставьте точку на нужное место и нажмите «Взять цвет»";
        TextView subV = ui.text(sub, 12, Theme.MUTED, false);
        subV.setLineSpacing(0, 1.2f);
        tx.addView(subV, Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(3), 0, 0));
        row.addView(tx, Ui.margins(0, Ui.WRAP, ui.dp(12), 0, 0, 0));
        ((LinearLayout.LayoutParams) tx.getLayoutParams()).weight = 1f;
        f.box.addView(row);
        if (t.mode == Model.MATCH) {
            f.button("Взять цвет под точкой", true, () -> pick(w));
            f.chips("Условие", new String[]{"Цвет такой", "Цвет НЕ такой"}, w.invert ? 1 : 0, k -> {
                w.invert = k == 1;
                changed();
            });
        }
        f.buttons("Настройки " + Board.letter(ti), false, () -> triggerCard(t), "Удалить", false, () -> {
            t.watches.remove(w);
            if (t.need > t.watches.size()) t.need = 0;
            changed();
            onTapEmpty();
        });
    }

    // ---------------------------------------------------------------- триггер

    private void triggerCard(Model.Trigger t) {
        int ti = s.triggers.indexOf(t);
        if (ti < 0) return;
        int nearY = t.watches.isEmpty() ? svc.realSize()[1] / 2 : t.watches.get(0).y;
        board.selected = null;
        board.invalidate();
        Form f = startCard("Триггер " + Board.letter(ti) + " · клик по цвету", Board.triggerColor(ti), t, nearY);
        f.toggle("Включён", null, t.enabled, on -> { t.enabled = on; changed(); });
        f.chips("Когда нажимать", new String[]{"Цвета как образцы", "Цвета одинаковые"}, t.mode, k -> {
            t.mode = k;
            if (k == Model.SAME && t.need == 1) t.need = 2;
            changed();
            triggerCard(t);
        });
        int n = t.watches.size();
        int minNeed = t.mode == Model.SAME ? 2 : 1;
        if (n >= minNeed) {
            int cur = t.need <= 0 || t.need > n ? n : t.need;
            f.counter(t.mode == Model.SAME ? "Сколько точек одного цвета" : "Сколько точек должно совпасть", cur, minNeed, Math.max(minNeed, n),
                    v -> v >= n ? (n == 1 ? "1" : "все " + n) : v + " из " + n, v -> { t.need = v >= n ? 0 : v; changed(); });
        }
        if (t.mode == Model.SAME) {
            f.note("Ставьте точки там, где цвет меняется: одинаковый фон тоже считается совпадением.");
        }
        f.slider("Допуск цвета", 60, t.tolerance, v -> v == 0 ? "точно" : "±" + v + "%", v -> { t.tolerance = v; changed(); });
        f.duration("Держится не меньше", t.holdMs, 0, 600_000, v -> { t.holdMs = (int) v; changed(); });
        f.chips("Сколько раз", new String[]{"Один раз за появление", "Пока держится"}, t.fire, k -> { t.fire = k; changed(); triggerCard(t); });
        f.duration(t.fire == Model.REPEAT ? "Нажимать каждые" : "Не чаще, чем раз в", t.cooldownMs, 0, 3_600_000, v -> { t.cooldownMs = (int) v; changed(); });
        if (t.actions.size() > 1) {
            f.toggle("Все нажатия одновременно", "Мультитач: несколько пальцев сразу", t.together, on -> { t.together = on; changed(); });
        }
        liveText = f.note("");
        liveTrigger = t;
        f.buttons("+ Точка проверки", false, () -> {
            Model.Watch w = new Model.Watch();
            place(w, t.watches.isEmpty() ? null : t.watches.get(t.watches.size() - 1));
            t.watches.add(w);
            changed();
            onSelect(w);
        }, "+ Точка нажатия", false, () -> {
            Model.Target a = new Model.Target();
            int[] pt = spot();
            a.x = pt[0];
            a.y = pt[1];
            a.delayMs = 50;
            t.actions.add(a);
            changed();
            onSelect(a);
        });
        f.button("Удалить триггер " + Board.letter(ti), false, () -> {
            s.triggers.remove(t);
            changed();
            onTapEmpty();
        });
        if (!t.watches.isEmpty() && !svc.captureReady()) svc.requestCapture();
    }

    // ---------------------------------------------------------------- добавить

    void addMenu() {
        if (svc.runner.state == Runner.RUNNING) togglePlay();
        if (markersHidden) {
            markersHidden = false;
            refresh();
        }
        board.selected = null;
        board.invalidate();
        Form f = startCard("Добавить", Theme.ACCENT, "menu", svc.realSize()[1] * 3 / 4);
        f.note("Клики по кругу выполняются по порядку снова и снова. Клики по цвету срабатывают, когда в точках появились нужные цвета.");
        f.section("КЛИКИ ПО КРУГУ");
        f.button("Точка нажатия", true, () -> addTarget(Model.TAP));
        f.buttons("Свайп", false, () -> addTarget(Model.SWIPE), "Долгое нажатие", false, () -> addTarget(Model.LONG));
        f.section("КЛИКИ ПО ЦВЕТУ");
        f.button("Цвета совпали с образцами → нажать", false, () -> addTrigger(Model.MATCH));
        f.button("Две и больше точек одного цвета → нажать", false, () -> addTrigger(Model.SAME));
        if (!s.triggers.isEmpty()) {
            f.section("К ТРИГГЕРУ");
            for (int i = 0; i < s.triggers.size(); i++) {
                Model.Trigger t = s.triggers.get(i);
                f.button("Настроить триггер " + Board.letter(i) + " (" + Logic.plural(t.watches.size(), "точка", "точки", "точек") + ")", false, () -> triggerCard(t));
            }
        }
    }

    private void addTarget(int type) {
        Model.Target t = new Model.Target();
        int[] p = spot();
        t.x = p[0];
        t.y = p[1];
        t.type = type;
        if (type == Model.SWIPE) {
            t.x2 = Math.min(svc.realSize()[0] - 1, t.x + ui.dp(140));
            t.y2 = t.y;
            t.holdMs = 300;
        }
        if (type == Model.LONG) t.holdMs = 800;
        s.targets.add(t);
        changed();
        onSelect(t);
        svc.toast("Перетащите точку на нужное место");
    }

    private void addTrigger(int mode) {
        Model.Trigger t = new Model.Trigger();
        t.mode = mode;
        int[] size = svc.realSize();
        int cx = size[0] / 2, cy = size[1] / 2 - ui.dp(60) + (s.triggers.size() % 4) * ui.dp(30);
        for (int i = 0; i < 2; i++) {
            Model.Watch w = new Model.Watch();
            w.x = cx + (i == 0 ? -ui.dp(70) : ui.dp(70));
            w.y = cy;
            t.watches.add(w);
        }
        Model.Target a = new Model.Target();
        a.x = cx;
        a.y = cy + ui.dp(110);
        a.delayMs = 50;
        t.actions.add(a);
        if (mode == Model.SAME) t.tolerance = 6;
        s.triggers.add(t);
        changed();
        svc.requestCapture();
        triggerCard(t);
        svc.toast(mode == Model.SAME ? "Поставьте кольца на точки, которые сравниваем" : "Поставьте кольца на нужные места — цвет возьмётся сам");
    }

    /** Свободное место для новой точки — недалеко от центра, не друг на друге. */
    private int[] spot() {
        int[] size = svc.realSize();
        int n = Board.targetsOf(s).size();
        int x = size[0] / 2 + ((n % 5) - 2) * ui.dp(48);
        int y = size[1] / 2 + ((n / 5) % 4 - 1) * ui.dp(56);
        return new int[]{Math.max(0, Math.min(size[0] - 1, x)), Math.max(0, Math.min(size[1] - 1, y))};
    }

    private void place(Model.Watch w, Model.Watch near) {
        int[] size = svc.realSize();
        if (near != null) {
            w.x = Math.min(size[0] - 1, near.x + ui.dp(56));
            w.y = near.y;
        } else {
            w.x = size[0] / 2;
            w.y = size[1] / 2;
        }
    }

    // ---------------------------------------------------------------- настройки сценария

    private void scenarioCard() {
        if (svc.runner.state == Runner.RUNNING) togglePlay();
        board.selected = null;
        board.invalidate();
        Form f = startCard(s.name, Theme.ACCENT, s, svc.realSize()[1] * 3 / 4);
        f.section("ПО КРУГУ");
        f.counter("Сколько кругов", s.cycles, 0, 1_000_000, v -> v == 0 ? "∞" : String.valueOf(v), v -> { s.cycles = v; changed(); });
        f.duration("Остановить через", s.stopAfterMs, 0, 24 * 3_600_000L, v -> { s.stopAfterMs = v; changed(); });
        f.note(s.stopAfterMs == 0 ? "0 — без ограничения по времени" : "");
        f.section("КАК ЧЕЛОВЕК");
        f.slider("Случайность пауз", 50, s.jitterPct, v -> v == 0 ? "нет" : "±" + v + "%", v -> { s.jitterPct = v; changed(); });
        f.slider("Разброс места нажатия", 40, s.jitterPx, v -> v == 0 ? "нет" : "±" + v + " px", v -> { s.jitterPx = v; changed(); });
        f.duration("Длительность нажатия", s.pressMs, 1, 2000, v -> { s.pressMs = (int) v; changed(); });
        f.duration("Случайная добавка к нажатию", s.pressJitterMs, 0, 1000, v -> { s.pressJitterMs = (int) v; changed(); });
        f.section("ЦВЕТА ЭКРАНА");
        String[] hz = {"5", "10", "20", "30", "60"};
        int[] hzV = {5, 10, 20, 30, 60};
        int sel = 2;
        for (int i = 0; i < hzV.length; i++) if (hzV[i] == s.checkHz) sel = i;
        f.chips("Проверок в секунду", hz, sel, k -> { s.checkHz = hzV[k]; changed(); });
        if (Build.VERSION.SDK_INT >= 30) {
            f.chips("Как смотреть на экран", new String[]{"Запись экрана", "Снимки (без записи)"}, s.capture, k -> {
                if (s.capture == k) return;
                s.capture = k;
                changed();
                if (k == 0) svc.closeShots();
                else CaptureService.stop(svc);
                svc.requestCapture();
            });
            f.note("Запись экрана — до 60 проверок в секунду, система спросит разрешение. Снимки — без разрешения, но не чаще 3 раз в секунду.");
        }
        f.section("УДОБСТВО");
        f.toggle("Умная пауза", "Остановиться, если открыто другое приложение, и продолжить, когда вернётесь", s.smartPause, on -> { s.smartPause = on; changed(); });
        Prefs pr = new Prefs(svc);
        f.toggle("Громкость вниз — пауза", "Аварийная остановка кнопкой громкости, пока кликер работает", pr.volumeStop(), on -> pr.put("volumeStop", on));
        f.counter("Размер меток", pr.markerSize(), 60, 160, v -> v + "%", v -> {
            pr.put("markerSize", v);
            board.scale = v / 100f;
            board.invalidate();
        });
        f.buttons("Открыть приложение", false, () -> {
            Intent i = new Intent(svc, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            svc.startActivity(i);
            svc.closeOverlay();
        }, "Готово", true, this::hideCard);
    }

    // ================================================================== сохранение

    private final Runnable saveRun = this::save;

    private void changed() {
        s.edited = System.currentTimeMillis();
        if (svc.runner.state == Runner.PAUSED) svc.runner.rebuild();
        board.invalidate();
        h.removeCallbacks(saveRun);
        h.postDelayed(saveRun, 400);
    }

    void save() {
        String json = Model.toJson(s);
        Context app = svc.getApplicationContext();
        SAVE.execute(() -> {
            try {
                Store.save(app, Model.fromJson(json));
            } catch (Exception ignored) {
            }
        });
    }
}
